/*****************************************************************************
* Copyright(C) 2013 Dong-A University MICCA
* All right reserved.
*
* File name	    : diskio.c
* Last version	: V1.00
* Description	: This file is source file for disk i/o interface.
*
* History
* Date		    Version	    Author			Description
* 2013/06/25	1.00		oh woomin	    Created
*****************************************************************************/

/* Includes ----------------------------------------------------------------*/
#include "stm324xg_sdio_sd.h"
#include "diskio.h"

/* Privated variables ------------------------------------------------------*/
static volatile
DSTATUS Stat = STA_NOINIT;	/* Disk status */

/*****************************************************************************
* Descriptions  : Initialize Disk Drive
* Parameters    : disk drive
* Return Value  : disk status
*****************************************************************************/
DSTATUS disk_initialize (
	BYTE drv		/* Physical drive number (0) */
)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    
    /* Configure the NVIC Preemption Priority Bits */
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    
    NVIC_InitStructure.NVIC_IRQChannel = SDIO_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel = SD_SDIO_DMA_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_Init(&NVIC_InitStructure);      
    
    if (drv) return STA_NOINIT;			/* Supports only single drive */

    if(SD_Init() == SD_OK) Stat &= ~STA_NOINIT;
    else Stat |= STA_NOINIT;

    return Stat;
}

/*****************************************************************************
* Descriptions  : Get Disk Status                                                
* Parameters    : disk drive
* Return Value  : disk status
*****************************************************************************/
DSTATUS disk_status (
	BYTE drv		/* Physical drive number (0) */
)
{
	if (drv) return STA_NOINIT;		/* Supports only single drive */
    return Stat;
}


/*****************************************************************************
* Descriptions  : Read Sector(s)
* Parameters    : drive, buffer, sector, sector count
* Return Value  : disk result
*****************************************************************************/
DRESULT disk_read (
	BYTE drv,			/* Physical drive number (0) */
	BYTE *buff,			/* Pointer to the data buffer to store read data */
	DWORD sector,		/* Start sector number (LBA) */
	BYTE count			/* Sector count (1..255) */
)
{
    SD_Error status = SD_OK;
    
	if (drv || !count) return RES_PARERR;
	if (Stat & STA_NOINIT) return RES_NOTRDY;
    
    if(count == 1)
    {
        status = SD_ReadBlock(buff, sector<<9, 512);
        status = SD_WaitReadOperation();
        while(SD_GetStatus() != SD_TRANSFER_OK);        

        if(status == SD_ERROR) return RES_ERROR;
    }
    else
    {
        status = SD_ReadMultiBlocks(buff, sector<<9, 512, count);
        status = SD_WaitReadOperation();
        while(SD_GetStatus() != SD_TRANSFER_OK);        

        if(status == SD_ERROR) return RES_ERROR;
    }        
	return RES_OK;        
}

/*****************************************************************************
* Descriptions  : Write Sector(s) 
* Parameters    : drive, buffer, sector, sector count
* Return Value  : disk result
*****************************************************************************/
DRESULT disk_write (
	BYTE drv,			/* Physical drive number (0) */
	const BYTE *buff,	/* Pointer to the data to be written */
	DWORD sector,		/* Start sector number (LBA) */
	BYTE count			/* Sector count (1..255) */
)
{
    SD_Error status = SD_OK;    
    
	if (drv || !count) return RES_PARERR;
	if (Stat & STA_NOINIT) return RES_NOTRDY;
	if (Stat & STA_PROTECT) return RES_WRPRT;    
    
    if(count == 1)
    {
        status = SD_WriteBlock((uint8_t *)buff, sector<<9, 512);
        status = SD_WaitWriteOperation();
        while(SD_GetStatus() != SD_TRANSFER_OK);
        
        if(status == SD_ERROR) return RES_ERROR;   
    }
    else
    {
        status = SD_WriteMultiBlocks((uint8_t *)buff, sector<<9, 512, count);        
        status = SD_WaitWriteOperation();
        while(SD_GetStatus() != SD_TRANSFER_OK);        
        
        if(status == SD_ERROR) return RES_ERROR;
    }
    return RES_OK;
}

/*****************************************************************************
* Descriptions  : Miscellaneous Functions  
* Parameters    : drive, control code, buffer
* Return Value  : disk result
*****************************************************************************/
DRESULT disk_ioctl (
	BYTE drv,		/* Physical drive number (0) */
	BYTE ctrl,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	if (drv) return RES_PARERR;
    return RES_OK;    
}
