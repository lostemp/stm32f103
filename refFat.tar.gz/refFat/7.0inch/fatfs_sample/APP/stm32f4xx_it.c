/**
  ******************************************************************************
  * @file    SDIO/uSDCard/stm32f4xx_it.c 
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    30-September-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_it.h"
#include "stm324xg_sdio_sd.h"
#include "stm32_systick.h"
#include "stm32_uart.h"
#include "tftlcd.h"
#include "platform_config.h"

/** @addtogroup STM32F4xx_StdPeriph_Examples
  * @{
  */

/** @addtogroup SDIO_uSDCard
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define Bank1_SRAM2_ADDR        0x64000000
#define SRAM_CAMERA_ADDR        0
#define DCMI_IMAGE_SRAM_ADDRESS (Bank1_SRAM2_ADDR+SRAM_CAMERA_ADDR)

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles PendSV_Handler exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
int SystickCount;
EventType Event;
volatile vu32 Timer;

void ClearSystickEvent(void)
{
    SystickCount = 0;    
    Event.Led1 = 0;
    Event.Touch = 0;
}

void SysTick_Handler(void)
{
    Timer++;
    DecrementTimingDelay();   
    
    if(++SystickCount == 10000) SystickCount = 0;
    if(SystickCount%100 == 0) Event.Led1 = 1;       
    if(SystickCount%5 == 0) Event.Touch = 1;
}

/******************************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/******************************************************************************/
/**
  * @brief  This function handles SDIO global interrupt request.
  * @param  None
  * @retval None
  */
void SDIO_IRQHandler(void)
{
    /* Process All SDIO Interrupt Sources */
    SD_ProcessIRQSrc();
}

/**
* @brief  This function handles DMA2 Stream3 or DMA2 Stream6 global interrupts
*         requests.
* @param  None
* @retval None
*/
void SD_SDIO_DMA_IRQHANDLER(void)
{
    /* Process DMA2 Stream3 or DMA2 Stream6 Interrupt Sources */
    SD_ProcessDMAIRQ();
}

/**
  * @brief  This function handles USART1 global interrupt request.
  * @param  None
  * @retval None
  */
void USART1_IRQHandler(void)
{    
    u8 data;
    
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {         
        if(enqueue(&Uart1RxQueue, USART_ReceiveData(USART1)) != QUEUE_SUCCESS)
        {            
        }           
    }
    if(USART_GetITStatus(USART1, USART_IT_TXE) != RESET)
    {                
        if(dequeue(&Uart1TxQueue, &data) == QUEUE_SUCCESS) 
        {
            /* Write one byte to the transmit data register */
            USART_SendData(USART1, data);            
        }
        else
        {
            /* Disable the USART1 Transmit interrupt */
            USART_ITConfig(USART1, USART_IT_TXE, DISABLE);       
        }              
    }        
}

/**
  * @brief  This function handles USART3 global interrupt request.
  * @param  None
  * @retval None
  */
void USART3_IRQHandler(void)
{    
    u8 data;
    
    if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
    {         
        if(enqueue(&Uart3RxQueue, USART_ReceiveData(USART3)) != QUEUE_SUCCESS)
        {            
        }           
    }
    if(USART_GetITStatus(USART3, USART_IT_TXE) != RESET)
    {                
        if(dequeue(&Uart3TxQueue, &data) == QUEUE_SUCCESS) 
        {
            /* Write one byte to the transmit data register */
            USART_SendData(USART3, data);            
        }
        else
        {
            /* Disable the USART1 Transmit interrupt */
            USART_ITConfig(USART3, USART_IT_TXE, DISABLE);       
        }              
    }        
}


vu32 CameraEvent;
vu32 ucCount;
void DMA2_Stream1_IRQHandler(void)
{
    /* This DMA is used for transferring the DCMI Data */
    if(DMA_GetITStatus(DMA2_Stream1,DMA_IT_TCIF1) != RESET)
    {
        DMA_ClearITPendingBit(DMA2_Stream1,DMA_IT_TCIF1);      
        
        ucCount++;        
        if(ucCount == 1)
        {
            DMA2_Stream1->M0AR = DCMI_IMAGE_SRAM_ADDRESS + 38400*4*2;                                            
        }                 
        else if(ucCount == 2)
        {
            DMA2_Stream1->M1AR = DCMI_IMAGE_SRAM_ADDRESS + 38400*4*3;                                                 
        }     
        else if(ucCount == 3)
        {
            DMA2_Stream1->M0AR = DCMI_IMAGE_SRAM_ADDRESS;    
            CameraEvent = 1;                            
        }
        else if(ucCount == 4)
        {
            DMA2_Stream1->M1AR = DCMI_IMAGE_SRAM_ADDRESS + 38400*4;                       
            ucCount = 0;                        
        }
    }    
      
}


/******************************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f4xx.s).                                               */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
