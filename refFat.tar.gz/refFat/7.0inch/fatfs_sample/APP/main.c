/*****************************************************************************
* Copyright(C) 2013 Dong-A University MICCA
* All right reserved.
*
* File name	    : main.c
* Platform 
* - Target Board: STM3240IG Module + 7.0" SSD1963 Module
* - Complier    : IAR EWARM V6.30
* - Library     : Stdperiph driver V1.10
*                 FatFs 
* Last version	: V1.00
* Description	: This file is main program for FatFs sample project.
*
* History
* Date		    Version	    Author			Description
* 2013/5/01     1.00        oh woomin       Created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include "stm32f4xx.h"
#include "stm32f4xx_it.h"
#include "platform_config.h"
#include "typedef.h"
#include "delay.h"
#include "stm32_uart.h"
#include "tftlcd.h"
#include "rgb_color_table.h"
#include "stm324xg_fsmc_sram.h"
#include "stm32_systick.h"
#include "touch_api.h"
#include "fatfs_api.h"

/* Privated macro ----------------------------------------------------------*/
/* Privated defines --------------------------------------------------------*/
// SRAM address area
#define Bank1_SRAM2_ADDR        0x64000000
#define SRAM_CAMERA_ADDR        0
#define DCMI_IMAGE_SRAM_ADDRESS (Bank1_SRAM2_ADDR+SRAM_CAMERA_ADDR)

/* Privated variables ------------------------------------------------------*/
POINT DispPoint;
u16 FontColor = RGB_BLACK, BgColor = RGB_WHITE;

DWORD AccSize;				/* Work register for fs command */
WORD AccFiles, AccDirs;
FILINFO Finfo;

#if _USE_LFN
char Lfname[512];
#endif

char Line[80];				/* Console input buffer */
BYTE Buff[2048];			/* Working buffer */

FATFS Fatfs[_VOLUMES];		/* File system object for each logical drive */
FIL File[2];				/* File object */
DIR Dir;					/* Directory object */

/* Privated typedef --------------------------------------------------------*/
typedef enum {CAMERA_SCREEN, PHOTO_SCREEN, FILE_SCREEN} ScreenType;

/* Privated function prototypes --------------------------------------------*/

/*****************************************************************************
* Descriptions : Configure the user LED
* Parameters : None
* Return Value : None
*****************************************************************************/
void UserLedConfig(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
            
    /* GPIOF Periph clock enable */
    RCC_AHB1PeriphClockCmd(LED_PERIPH, ENABLE);
    
    /* Configure PG6 and PG8 in output pushpull mode */
    GPIO_InitStructure.GPIO_Pin = LED1_BIT | LED2_BIT |LED3_BIT | LED4_BIT;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(LED_PORT, &GPIO_InitStructure);
    
    LED1_OFF(); LED2_OFF(); LED3_OFF(); LED4_OFF();       
}

/*****************************************************************************
* Descriptions : Configure the user switch
* Parameters : None
* Return Value : None
*****************************************************************************/
void UserSwConfig(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
    
	/* Enable the user SW1, SW2 clock */
	RCC_APB1PeriphClockCmd(USER_SW_PERIPH, ENABLE);
    
	/* Configure the user SW1, SW2 pin */
    GPIO_InitStructure.GPIO_Pin = USER_SW1_BIT | USER_SW2_BIT;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
    GPIO_Init(USER_SW_PORT, &GPIO_InitStructure);
}

/*****************************************************************************
* Descriptions : Initializes the system
* Parameters : None
* Return Value : None
*****************************************************************************/
void SystemConfig(void)
{
    UserLedConfig();
    UserSwConfig();
    UART_Init(UART1, 115200);
    SystickInit(1000);          // Systick timer 1kHz = 1ms  
    SRAM_Init();
    
    TFTLCD_Init();
    TFTLCD_SetBackLight(220);   // Backlight brightness 0(min)~255(max)
    TFTLCD_BL_ON();
    TFTLCD_Landscape();
}

static FRESULT scan_files (char* path)
{
	DIR dirs;
	FRESULT res;
	int i;
	char *fn;

	res = f_opendir(&dirs, path);
	if (res == FR_OK) {
		i = strlen(path);
		while (((res = f_readdir(&dirs, &Finfo)) == FR_OK) && Finfo.fname[0]) {
			if (_FS_RPATH && Finfo.fname[0] == '.') continue;
#if _USE_LFN
			fn = *Finfo.lfname ? Finfo.lfname : Finfo.fname;
#else
			fn = Finfo.fname;
#endif
			if (Finfo.fattrib & AM_DIR) {
				AccDirs++;
				path[i] = '/'; strcpy(path+i+1, fn);
				res = scan_files(path);
				path[i] = '\0';
				if (res != FR_OK) break;
			} else {
				AccFiles++;
				AccSize += Finfo.fsize;
			}
		}
	}
	return res;
}

/*****************************************************************************
* Descriptions : Main program
* Parameters : None
* Return Value : None
*****************************************************************************/
int main(void)
{       
	char *ptr, *ptr2;
	long p1, p2;
	BYTE res;   
	UINT s1, s2, cnt;    
	DWORD ofs; 
	FATFS *fs;
    
    SystemConfig();    
#if _USE_LFN
    Finfo.lfname = Lfname;
    Finfo.lfsize = sizeof(Lfname);
#endif   
    
    TFTLCD_printf(32, 4, RGB_ORANGE, RGB_WHITE, "FAT file system sample program for FatFs");   
    UART1_printf("FAT file system sample program for FatFs\n");
    
    ClearSystickEvent();   

    while(1)
    {       
		uart_putc('>');
		ptr = Line;

		get_line(ptr, sizeof Line);
		switch (*ptr++)
        {
		case 'f' :
			switch (*ptr++) {

			case 'i' :	/* fi <log drv#> - Initialize logical drive */
				if (!xatoi(&ptr, &p1)) break;
				put_rc(f_mount((BYTE)p1, &Fatfs[p1]));
				break;

			case 's' :	/* fs [<path>] - Show logical drive status */
				while (*ptr == ' ') ptr++;
				ptr2 = ptr;
				res = f_getfree(ptr, (DWORD*)&p2, &fs);
				if (res) { put_rc(res); break; }
				UART1_printf("FAT type = %u\nBytes/Cluster = %lu\nNumber of FATs = %u\n"
							 "Root DIR entries = %u\nSectors/FAT = %lu\nNumber of clusters = %lu\n"
							 "FAT start (lba) = %lu\nDIR start (lba,clustor) = %lu\nData start (lba) = %lu\n\n",
						fs->fs_type, (DWORD)fs->csize * 512, fs->n_fats,
						fs->n_rootdir, fs->fsize, fs->n_fatent - 2,
						fs->fatbase, fs->dirbase, fs->database
				);
#if _USE_LABEL
				res = f_getlabel(ptr2, (char*)Buff, (DWORD*)&p1);
				if (res) { put_rc(res); break; }
				UART1_printf(Buff[0] ? "Volume name is %s\n" : "No volume label\n", Buff);
				UART1_printf("Volume S/N is %04X-%04X\n", (WORD)((DWORD)p1 >> 16), (WORD)(p1 & 0xFFFF));
#endif
				UART1_printf("...");
				AccSize = AccFiles = AccDirs = 0;
				strcpy((char*)Buff, ptr);
				res = scan_files((char*)Buff);
				if (res) { put_rc(res); break; }
				UART1_printf("\r%u files, %lu bytes.\n%u folders.\n"
							 "%lu KB total disk space.\n%lu KB available.\n",
						AccFiles, AccSize, AccDirs,
						(fs->n_fatent - 2) * (fs->csize / 2), p2 * (fs->csize / 2)
				);
				break;
                
			case 'l' :	/* fl [<path>] - Directory listing */
				while (*ptr == ' ') ptr++;
				res = f_opendir(&Dir, ptr);
				if (res) { put_rc(res); break; }
				p1 = s1 = s2 = 0;
				for(;;) {
					res = f_readdir(&Dir, &Finfo);
					if ((res != FR_OK) || !Finfo.fname[0]) break;
					if (Finfo.fattrib & AM_DIR) {
						s2++;
					} else {
						s1++; p1 += Finfo.fsize;
					}
					UART1_printf("%c%c%c%c%c %u/%02u/%02u %02u:%02u %9lu  %-12s  %s\n",
							(Finfo.fattrib & AM_DIR) ? 'D' : '-',
							(Finfo.fattrib & AM_RDO) ? 'R' : '-',
							(Finfo.fattrib & AM_HID) ? 'H' : '-',
							(Finfo.fattrib & AM_SYS) ? 'S' : '-',
							(Finfo.fattrib & AM_ARC) ? 'A' : '-',
							(Finfo.fdate >> 9) + 1980, (Finfo.fdate >> 5) & 15, Finfo.fdate & 31,
							(Finfo.ftime >> 11), (Finfo.ftime >> 5) & 63,
							Finfo.fsize, Finfo.fname,
#if _USE_LFN
							Lfname);
#else
							"");
#endif
				}
				UART1_printf("%4u File(s),%10lu bytes total\n%4u Dir(s)", s1, p1, s2);
				res = f_getfree(ptr, (DWORD*)&p1, &fs);
				if (res == FR_OK)
					UART1_printf(", %10lu bytes free\n", p1 * fs->csize * 512);
				else
					put_rc(res);
				break;              

			case 'o' :	/* fo <mode> <name> - Open a file */
				if (!xatoi(&ptr, &p1)) break;
				while (*ptr == ' ') ptr++;
				put_rc(f_open(&File[0], ptr, (BYTE)p1));
				break;

			case 'c' :	/* fc - Close a file */
				put_rc(f_close(&File[0]));
				break;

			case 'e' :	/* fe - Seek file pointer */
				if (!xatoi(&ptr, &p1)) break;
				res = f_lseek(&File[0], p1);
				put_rc(res);
				if (res == FR_OK)
					UART1_printf("fptr = %lu(0x%lX)\n", File[0].fptr, File[0].fptr);
				break;

			case 'r' :	/* fr <len> - read file */
				if (!xatoi(&ptr, &p1)) break;
				p2 = 0;
				Timer = 0;
				while (p1) {
					if (p1 >= sizeof Buff)	{ cnt = sizeof Buff; p1 -= sizeof Buff; }
					else 			{ cnt = (WORD)p1; p1 = 0; }
					res = f_read(&File[0], Buff, cnt, &s2);
					if (res != FR_OK) { put_rc(res); break; }
					p2 += s2;
					if (cnt != s2) break;
				}
                UART1_printf("%lu bytes read with %lu kB/sec.\n", p2, Timer ? (p2 / Timer) : 0);                
				break;

			case 'd' :	/* fd <len> - read and dump file from current fp */
				if (!xatoi(&ptr, &p1)) break;
				ofs = File[0].fptr;
				while (p1) {
					if (p1 >= 16)	{ cnt = 16; p1 -= 16; }
					else 			{ cnt = (WORD)p1; p1 = 0; }
					res = f_read(&File[0], Buff, cnt, &cnt);
					if (res != FR_OK) { put_rc(res); break; }
					if (!cnt) break;
					put_dump(Buff, ofs, cnt);
					ofs += 16;
				}
				break;

			case 'w' :	/* fw <len> <val> - write file */
				if (!xatoi(&ptr, &p1) || !xatoi(&ptr, &p2)) break;
				memset(Buff, (BYTE)p2, sizeof Buff);
				p2 = 0;
                Timer = 0;
				while (p1) {
					if (p1 >= sizeof Buff)	{ cnt = sizeof Buff; p1 -= sizeof Buff; }
					else 			{ cnt = (WORD)p1; p1 = 0; }
					res = f_write(&File[0], Buff, cnt, &s2);
					if (res != FR_OK) { put_rc(res); break; }
					p2 += s2;
					if (cnt != s2) break;
				}
                UART1_printf("%lu bytes written with %lu kB/sec.\n", p2, Timer ? (p2 / Timer) : 0);   
				break;
                
			case 'u' :	/* fu <name> - Unlink an object */
				while (*ptr == ' ') ptr++;
				put_rc(f_unlink(ptr));
				break;                
			}
            break;
        }     
    }
}

