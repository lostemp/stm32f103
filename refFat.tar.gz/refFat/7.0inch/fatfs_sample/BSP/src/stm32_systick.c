/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : stm32_systick.c
* Last version	: V1.00
* Description	: This file is source file for systick timer.
*
* History
* Date		    Version	    Author			Description
* 2011/03/06	1.00		oh woomin	    create
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

static volatile uint32_t TimingDelay;

void SystickInit(uint32_t time)
{
    if (SysTick_Config(SystemCoreClock / time))
    { 
        /* Capture error */ 
        while (1);
    }    
}

void TimeDelay(uint32_t time)
{
    TimingDelay = time;
    while(TimingDelay != 0);
}

void DecrementTimingDelay(void)
{
    if (TimingDelay != 0x00)
    { 
        TimingDelay--;
    }    
}