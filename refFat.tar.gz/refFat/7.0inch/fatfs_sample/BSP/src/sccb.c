/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : sccb.c
* Last version	: V1.00
* Description	: This file is source file for sccb interface.
*
* History
* Date		    Version	    Author			Description
* 2011/07/16	1.00		oh woomin	    Created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "sccb.h"
#include "delay.h"

void SCCB_PortInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
     
    /* GPIOG Periph clock enable */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    
    /* Configure PG6 and PG8 in output pushpull mode */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);    
    
    SCCB_SIC_H();
    SCCB_SID_H();
}

void SCCB_SidOutput(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(SCCB_SID_PERIPH, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin =  SCCB_SID_BIT;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(SCCB_SID_PORT, &GPIO_InitStructure);      
}

void SCCB_SidInput(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(SCCB_SID_PERIPH, ENABLE);

    GPIO_InitStructure.GPIO_Pin = SCCB_SID_BIT;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;    
    GPIO_Init(SCCB_SID_PORT, &GPIO_InitStructure);    
    
}

void SCCB_Start(void)
{
    SCCB_SID_H();
    delay_us(200);

    SCCB_SIC_H();
    delay_us(200);
 
    SCCB_SID_L();
    delay_us(200);

    SCCB_SIC_L();
    delay_us(200);
}


void SCCB_Stop(void)
{
    SCCB_SID_L();
    delay_us(200);
 
    SCCB_SIC_H();	
    delay_us(200);
  
    SCCB_SID_H();	
    delay_us(200);
}

void SCCB_NoAck(void)
{	
	SCCB_SID_H();	
    delay_us(200);
	
	SCCB_SIC_H();	
    delay_us(200);
	
	SCCB_SIC_L();	
    delay_us(200);
	
	SCCB_SID_L();	
    delay_us(200);
}

unsigned char SCCB_WriteByte(unsigned char m_data)
{
	unsigned char j, tem;

	for(j=0;j<8;j++)
	{
		if((m_data<<j)&0x80)
		{
			SCCB_SID_H();	
		}
		else
		{
			SCCB_SID_L();	
		}
        delay_us(200);
		SCCB_SIC_H();	
        delay_us(200);
    	SCCB_SIC_L();	
        delay_us(200);
	}
    delay_us(200);
	SCCB_SidInput();
    delay_us(200);
	SCCB_SIC_H();	
    delay_us(200);
    
	if(SCCB_SID_STATE()){tem=0;}
	else {tem=1;}
	SCCB_SIC_L();	
    delay_us(200);
    SCCB_SidOutput();
	return (tem);  
}

unsigned char SCCB_ReadByte(void)
{
	unsigned char read,j;
	read=0x00;

	SCCB_SidInput();
    delay_us(200);
	for(j=8;j>0;j--)
	{		     
        delay_us(200);
		SCCB_SIC_H();
        delay_us(200);
		read=read<<1;
		if(SCCB_SID_STATE()) 
		{
			read=read+1;
		}
		SCCB_SIC_L();
        delay_us(200);
	}	
	return(read);
}
