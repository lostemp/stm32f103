/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : tftlcd.c
* Last version	: V1.00
* Description	: This file is source file for TFT LCD(SSD1963) display
*
* History
* Date		    Version	    Author			Description
* 2011/06/13	1.00		oh woomin	    Created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <stdarg.h>
#include <stdio.h>
#include <math.h>
#include "stm32f4xx.h"
#include "platform_config.h"
#include "tftlcd.h"
#include "delay.h"
#include "gothic16x16_kor.h"
#include "font8x16_ascii.h"
#include "kssm_table.h"
#include "rgb_color_table.h"
#include "stm324xg_sdio_sd.h"
#include "stm324xg_fsmc_sram.h"

/* Private typedef -----------------------------------------------------------*/
typedef struct
{
    vu16 TFTLCD_REG;
    vu16 TFTLCD_RAM;
} TFTLCD_TypeDef;

/* Private define ------------------------------------------------------------*/
/* Note: LCD /CS is CE4 - Bank 4 of NOR/SRAM Bank 1~4 */
#define TFTLCD_BASE             ((u32)(0x60000000 | 0x08000000))
#define TFTLCD                  ((TFTLCD_TypeDef *) TFTLCD_BASE)

#define Bank1_SRAM2_ADDR        ((uint32_t)0x64000000)  

#define TFTLCD_WriteReg(reg)    (TFTLCD->TFTLCD_REG = reg)
#define TFTLCD_WriteRam(dat)    (TFTLCD->TFTLCD_RAM = dat)

// SSD1963 Setting (LCD interface timing)
#define HDP     (800 - 1)       // HCYC(Horizontal Cycle)
#define HT      (824 - 1)       // HDP(Horizontal Display Period)
#define HPS     (16)            // HBP(Horizontal Back Porch)
#define LPS     (0)             
#define HPW     (3 - 1)         // HLW(Horizontal Low Width)

#define VDP     (480 - 1)       // VCYC(Vertical Cycle)
#define VT      (493 - 1)       // VDP(Vertical Display Period)
#define VPS     (8)             // VBP(Vertical Back Porch)
#define FPS     (0)             
#define VPW     (1 - 1)         // VLW(Vertical Low Width)

/*****************************************************************************
* Descriptions  : TFT LCD�� Landscape(����)�������� ǥ��.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
void TFTLCD_Landscape(void)
{
    TFTLCD_WriteReg(0x36);
    TFTLCD_WriteRam(0x00);                
}    

/*****************************************************************************
* Descriptions  : TFT LCD�� �̷��� Landscape(����)�������� ǥ��.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
void TFTLCD_XmirrLandscape(void)
{
    TFTLCD_WriteReg(0x36);
    TFTLCD_WriteRam(0x80);      
}    

/*****************************************************************************
* Descriptions  : TFT LCD�� Portrait(����)�������� ǥ��.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
void TFTLCD_Portrait(void)
{
    TFTLCD_WriteReg(0x36);
    TFTLCD_WriteRam(0x20);    
}

/*****************************************************************************
* Descriptions  : TFT LCD�� ǥ����ǥ�� ����.
* Parameters    : ������ǥ(x1,y1), ����ǥ(x2, y2)
* Return Value  : None
*****************************************************************************/
void TFTLCD_SetAddr(u16 x1, u16 y1, u16 x2, u16 y2)
{
    TFTLCD_WriteReg(0x2A);
    TFTLCD_WriteRam(x1>>8);
    TFTLCD_WriteRam(x1&0xFF);
    TFTLCD_WriteRam(x2>>8);
    TFTLCD_WriteRam(x2&0xFF);
    
    TFTLCD_WriteReg(0x2B);
    TFTLCD_WriteRam(y1>>8);
    TFTLCD_WriteRam(y1&0xFF);
    TFTLCD_WriteRam(y2>>8);
    TFTLCD_WriteRam(y2&0xFF);
    
    TFTLCD_WriteReg(0x2C);    
}

/*****************************************************************************
* Descriptions  : TFT LCD�� Backlight ��⸦ ����.
* Parameters    : ��� (0~255)
* Return Value  : None
*****************************************************************************/
void TFTLCD_SetBackLight(u8 bright)
{
    // PWM Configuration
    // PWM CLK = PLL CLK / (256*PWMF) / 256
    TFTLCD_WriteReg(0xBE);    
    TFTLCD_WriteRam(0x00);
    TFTLCD_WriteRam(0xFF-bright);
    TFTLCD_WriteRam(0x01);
    TFTLCD_WriteRam(0xFF);
    TFTLCD_WriteRam(0x00);
    TFTLCD_WriteRam(0x00);
}

/*****************************************************************************
* Descriptions  : LCD��Ʈ�ѷ��� SSD1963�� �ʱ�ȭ.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
static void TFTLCD_InitCode(void)
{            
    // Hardware reset 
    delay_ms(50);
    TFTLCD_RST_LOW();
    delay_ms(1);
    TFTLCD_RST_HIGH();         
        
    // Set the MN of PLL 
    // PLL Frequency = 10MHz*36/3 = 120MHz
    TFTLCD_WriteReg(0xE2);
    TFTLCD_WriteRam(35);            // N = 36-1
    TFTLCD_WriteRam(2);             // M = 3-1
    TFTLCD_WriteRam(0x04);          // Dummy byte
    
    // Set the PLL
    TFTLCD_WriteReg(0xE0);          
    TFTLCD_WriteRam(0x01);       
    delay_ms(1);        
    // Lock the PLL    
    TFTLCD_WriteReg(0xE0);
    TFTLCD_WriteRam(0x03);     
    delay_ms(1);        
    // Software reset
    TFTLCD_WriteReg(0x01);
    delay_ms(5);    
    
    // Set the pixel clock frequency
    // PCLK = 120MHz * (LCDC_FPR + 1) / 2^20    
    // PCLK 10MHz: LCDC_FPR = 0x15554
    // PCLK 24MHz: LCDC_FPR = 0x34443
    TFTLCD_WriteReg(0xE6);     
    TFTLCD_WriteRam(0x03);
    TFTLCD_WriteRam(0x44);
    TFTLCD_WriteRam(0x43);    
    
    // Set the LCD panel mode
    TFTLCD_WriteReg(0xB0);
    TFTLCD_WriteRam(0x18);          // Data width 18bit, TFT FRC enable 
    TFTLCD_WriteRam(0x00);          // Hsync+Vsync+DE mode, TFT mode
    TFTLCD_WriteRam((HDP>>8)&0xFF); // Horizontal panel size
    TFTLCD_WriteRam(HDP&0xFF);
    TFTLCD_WriteRam((VDP>>8)&0xFF); // Vertical panel size
    TFTLCD_WriteRam(VDP&0xFF);
    TFTLCD_WriteRam(0x00);
    
    // Set horizontal period
    TFTLCD_WriteReg(0xB4);
    TFTLCD_WriteRam((HT>>8)&0xFF);  // Horizontal total period
    TFTLCD_WriteRam(HT&0xFF);    
    TFTLCD_WriteRam((HPS>>8)&0xFF); // Horizontal non-display period 
    TFTLCD_WriteRam(HPS&0xFF);         
    TFTLCD_WriteRam(HPW);           // Horizontal sync pulse width
    TFTLCD_WriteRam((LPS>>8)&0xFF); // Horizontal sync pulse start location
    TFTLCD_WriteRam(LPS&0xFF);         
    TFTLCD_WriteRam(0);         
    
    // Set vertical period
    TFTLCD_WriteReg(0xB6);
    TFTLCD_WriteRam((VT>>8)&0xFF);  // Vertical total period
    TFTLCD_WriteRam(VT&0xFF);
    TFTLCD_WriteRam((VPS>>8)&0xFF); // Vertical non-display period      
    TFTLCD_WriteRam(VPS&0xFF);
    TFTLCD_WriteRam(VPW);           // Vertical sync pulse width
    TFTLCD_WriteRam((FPS>>8)&0xFF); // Vertical sync pulse start location
    TFTLCD_WriteRam(FPS&0xFF);         
    
    // Set the pixel data format - 16bit(565)
    TFTLCD_WriteReg(0xF0);
    TFTLCD_WriteRam(0x03);
        
    //Set GPIO configure
    TFTLCD_WriteReg(0xB8);
    TFTLCD_WriteRam(0x0F);     
    TFTLCD_WriteRam(0x01);    
       
    // Set display on   
    TFTLCD_WriteReg(0x29);                      
    delay_ms(50);
}
/*****************************************************************************
* Descriptions  : TFT LCD�� ����� ��Ʈ�� �ʱ�ȭ.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
static void TFTLCD_PortInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
            
    /* Enable GPIOD, GPIOE, GPIOF, GPIOG and AFIO clocks */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD | RCC_AHB1Periph_GPIOG | RCC_AHB1Periph_GPIOE |
                           RCC_AHB1Periph_GPIOF, ENABLE);
    
    /*-- GPIO Configuration ------------------------------------------------------*/
    /* SRAM Data lines,  NOE and NWE configuration */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_8 | GPIO_Pin_9 | 
        GPIO_Pin_10 | GPIO_Pin_14 | GPIO_Pin_15 |
        GPIO_Pin_4 |GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource0, GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource1, GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource4, GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource5, GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource8, GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource9, GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource10, GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource14, GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource15, GPIO_AF_FSMC);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 |
        GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | 
            GPIO_Pin_15;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
    
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource7 , GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource8 , GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource9 , GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource10 , GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource11 , GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource12 , GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource13 , GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource14 , GPIO_AF_FSMC);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource15 , GPIO_AF_FSMC);
    
    /* SRAM Address lines configuration */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_Init(GPIOF, &GPIO_InitStructure);  
    GPIO_PinAFConfig(GPIOF, GPIO_PinSource0, GPIO_AF_FSMC);	   
    
    /* NE3 configuration */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; 
    
    GPIO_Init(GPIOG, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOG, GPIO_PinSource10, GPIO_AF_FSMC);     
    
    // Set TFTLCD reset pin
    RCC_AHB1PeriphClockCmd(TFTLCD_RST_PERIPH, ENABLE);    
        
    GPIO_InitStructure.GPIO_Pin = TFTLCD_RST_BIT;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(TFTLCD_RST_PORT, &GPIO_InitStructure);
    
    // Set TFTLCD backlight enable pin    
    RCC_AHB1PeriphClockCmd(TFTLCD_BL_PERIPH, ENABLE);    
    
    GPIO_InitStructure.GPIO_Pin = TFTLCD_BL_BIT;
    GPIO_Init(TFTLCD_BL_PORT, &GPIO_InitStructure);      
    
    TFTLCD_RST_HIGH();  
    TFTLCD_BL_OFF();     
}

/*****************************************************************************
* Descriptions  : TFT LCD�� FSMC�� �ʱ�ȭ.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
static void TFTLCD_FsmcInit1(void)
{
    FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
    FSMC_NORSRAMTimingInitTypeDef  p;
    
    /* Enable FSMC clock */
    RCC_AHB3PeriphClockCmd(RCC_AHB3Periph_FSMC, ENABLE);
    
    /*-- FSMC Configuration ------------------------------------------------------*/
    /*----------------------- SRAM Bank 3 ----------------------------------------*/
    /* FSMC_Bank1_NORSRAM4 configuration */
    p.FSMC_AddressSetupTime = 10;
    p.FSMC_AddressHoldTime = 0;
    p.FSMC_DataSetupTime = 10;
    p.FSMC_BusTurnAroundDuration = 0;
    p.FSMC_CLKDivision = 0;
    p.FSMC_DataLatency = 0;
    p.FSMC_AccessMode = FSMC_AccessMode_A;
    /* Color LCD configuration ------------------------------------
    LCD configured as follow:
    - Data/Address MUX = Disable
    - Memory Type = SRAM
    - Data Width = 16bit
    - Write Operation = Enable
    - Extended Mode = Enable
    - Asynchronous Wait = Disable */
    
    FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM3;
    FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
    FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;
    FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
    FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_AsynchronousWait = FSMC_AsynchronousWait_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
    FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
    FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
    FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
    FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &p;
    FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &p;
    
    FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure);   
    
    /* Enable FSMC NOR/SRAM Bank3 */
    FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM3, ENABLE);
}

/*****************************************************************************
* Descriptions  : TFT LCD�� FSMC�� �ʱ�ȭ.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
static void TFTLCD_FsmcInit2(void)
{
    FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
    FSMC_NORSRAMTimingInitTypeDef  p;
    
    /* Enable FSMC clock */
    RCC_AHB3PeriphClockCmd(RCC_AHB3Periph_FSMC, ENABLE);
    
    /*-- FSMC Configuration ------------------------------------------------------*/
    /*----------------------- SRAM Bank 3 ----------------------------------------*/
    /* FSMC_Bank1_NORSRAM4 configuration */
    p.FSMC_AddressSetupTime = 1;
    p.FSMC_AddressHoldTime = 0;
    p.FSMC_DataSetupTime = 2;
    p.FSMC_BusTurnAroundDuration = 0;
    p.FSMC_CLKDivision = 0;
    p.FSMC_DataLatency = 0;
    p.FSMC_AccessMode = FSMC_AccessMode_A;
    /* Color LCD configuration ------------------------------------
    LCD configured as follow:
    - Data/Address MUX = Disable
    - Memory Type = SRAM
    - Data Width = 16bit
    - Write Operation = Enable
    - Extended Mode = Enable
    - Asynchronous Wait = Disable */
    
    FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM3;
    FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
    FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;
    FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
    FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_AsynchronousWait = FSMC_AsynchronousWait_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
    FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
    FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
    FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
    FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &p;
    FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &p;
    
    FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure);   
    
    /* Enable FSMC NOR/SRAM Bank3 */
    FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM3, ENABLE);
}

/*****************************************************************************
* Descriptions  : TFT LCD�� �ʱ�ȭ.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
void TFTLCD_Init(void)
{   
    TFTLCD_PortInit();
    TFTLCD_FsmcInit1();         
    TFTLCD_InitCode();     
    TFTLCD_FsmcInit2();         
    
    TFTLCD_Color(0, 0, LCD_WIDTH_SIZE , LCD_HEIGHT_SIZE, RGB_WHITE);
}

/*****************************************************************************
* Descriptions  : TFT LCD�� ������ ǥ��.
* Parameters    : ������ǥ(x,y), ������, Į��
* Return Value  : None
*****************************************************************************/
void TFTLCD_Color(u16 xStart, u16 yStart, u16 xSize, u16 ySize, u16 color)
{
    int i;
    int size = xSize*ySize/8;

    TFTLCD_SetAddr(xStart,yStart,xStart+xSize-1,yStart+ySize-1);
    
    for(i=0; i<size; i++)
    {
        TFTLCD_WriteRam(color);
        TFTLCD_WriteRam(color);
        TFTLCD_WriteRam(color);
        TFTLCD_WriteRam(color); 
        TFTLCD_WriteRam(color); 
        TFTLCD_WriteRam(color); 
        TFTLCD_WriteRam(color);   
        TFTLCD_WriteRam(color);    
    }                   
}    

/*****************************************************************************
* Descriptions  : TFT LCD�� ���� �׽�Ʈ ȭ���� ǥ��.
* Parameters    : ������ǥ(x,y), ������, ǥ�ø��
* Return Value  : None
*****************************************************************************/
void TFTLCD_ColorTest(u16 xStart,u16 yStart,u16 xSize,u16 ySize,u8 mode)
{
    const u16 ColorTable[] = {0xFFFF,0xFFE0,0x07FF,0x07E0,0xF81F,0xF800,0x001F,0x0000};
    const u16 GrayTable[] = {0xffff,0xd6ba,0xb5b6,0x94b2,0x738e,0x528a,0x3186,0x1082};
    
    int size, i, j;
    u16 color;
        
    if(mode == 0)
    {   
        size = (xSize/8) * (ySize/8);           

        TFTLCD_Landscape();
        TFTLCD_SetAddr(xStart, yStart, xStart+xSize-1, yStart+ySize-1);
        
        for(i=0; i<8; i++)
        {
            color = ColorTable[i];
            for(j=0; j<size; j++)
            {
                TFTLCD_WriteRam(color);   
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
            }                 
        }
    }       
    else if(mode == 1)
    {   
        size = (xSize/8) * (ySize/8);       
        
        TFTLCD_Portrait();        
        TFTLCD_SetAddr(xStart, yStart, xStart+xSize-1, yStart+ySize-1);
        
        for(i=0; i<8; i++)
        {
            color = ColorTable[i];
            for(j=0; j<size; j++)
            {
                TFTLCD_WriteRam(color);   
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);      
            }                   
        }              
    }   
    else if(mode == 2)
    {           
        size = (xSize/8) * (ySize/8);        
        
        TFTLCD_Landscape();        
        TFTLCD_SetAddr(xStart,yStart,xStart+xSize-1,yStart+ySize-1);
        
        for(i=0; i<8; i++)
        {
            color = GrayTable[i];
            for(j=0; j<size; j++)
            {
                TFTLCD_WriteRam(color);   
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);      
            }                 
        }              
    }    
    else if(mode == 3)
    {   
        size = (xSize/8) * (ySize/8);       
        
        TFTLCD_Portrait();        
        TFTLCD_SetAddr(xStart,yStart,xStart+xSize-1,yStart+ySize-1);
        
        for(i=0; i<8; i++)
        {
            color = GrayTable[i];
            for(j=0; j<size; j++)
            {
                TFTLCD_WriteRam(color);   
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);
                TFTLCD_WriteRam(color);     
            }                   
        }
    }          
}

/*****************************************************************************
* Descriptions  : TFT LCD�� 1�ȼ��� ǥ���Ѵ�.
* Parameters    : ǥ����ǥ(x,y), ����
* Return Value  : None
*****************************************************************************/
void TFTLCD_DrawPixel(u16 x, u16 y, u16 color)
{
    TFTLCD_SetAddr(x, y ,x, y);        
   	TFTLCD_WriteRam(color);
}

/*****************************************************************************
* Descriptions  : TFT LCD�� 3x3�ȼ��� ǥ��.
* Parameters    : ǥ����ǥ(x,y), ����
* Return Value  : None
*****************************************************************************/
void TFTLCD_DrawPen(u16 x, u16 y, u16 color)
{
    int i;
    
    TFTLCD_SetAddr(x-1, y+1 ,x+1, y-1);       

    for(i=0;i<9;i++)  
    {
       	TFTLCD_WriteRam(color);    
    }
}

/*****************************************************************************
* Descriptions  : TFT LCD�� ���� �׸���.
* Parameters    : ������ǥ(x1,y1), ����ǥ(x2,y2), ����
* Return Value  : None
*****************************************************************************/
void TFTLCD_DrawLine(s16 x1, s16 y1, s16 x2, s16 y2, u16 color)
{
    int x, y;
    
    if(y1 != y2)					// if y1 != y2, y is variable
    { 
        if(y1 < y2)
            for(y = y1; y <= y2; y++)
            { 
                x = x1 + (y - y1)*(x2 - x1)/(y2 - y1);
                TFTLCD_DrawPixel(x,y,color);            
            }
        else
            for(y = y1; y >= y2; y--)
            {  
                x = x1 + (y - y1)*(x2 - x1)/(y2 - y1);
                TFTLCD_DrawPixel(x,y,color);            
            }
        }
    else if(x1 != x2)				// if x1 != x2, x is variable
    { 
        if(x1 < x2)
            for(x = x1; x <= x2; x++)
            { 
                y = y1 + (x - x1)*(y2 - y1)/(x2 - x1);
                TFTLCD_DrawPixel(x,y,color);            
            }
        else
            for(x = x1; x >= x2; x--)
            { 
                y = y1 + (x - x1)*(y2 - y1)/(x2 - x1);
                TFTLCD_DrawPixel(x,y,color);
            }
        }
    else 
    {
        TFTLCD_DrawPixel(x1,y1,color);
    }
}

void TFTLCD_DrawRect(s16 x1, s16 y1, s16 x2, s16 y2, u16 color)     /* draw a rectangle */
{
    TFTLCD_DrawLine(x1,y1, x1,y2, color);			// horizontal line
    TFTLCD_DrawLine(x2,y1, x2,y2, color);
    TFTLCD_DrawLine(x1,y1, x2,y1, color);			// vertical line
    TFTLCD_DrawLine(x1,y2, x2,y2, color);
}

void TFTLCD_DrawRectFill(s16 x1, s16 y1, s16 x2, s16 y2, u16 color, u16 fill) /* draw a rectangle with filled color */
{
    int i;
    
    TFTLCD_DrawLine(x1,y1, x1,y2, color);			// horizontal line
    TFTLCD_DrawLine(x2,y1, x2,y2, color);
    TFTLCD_DrawLine(x1,y1, x2,y1, color);			// vertical line
    TFTLCD_DrawLine(x1,y2, x2,y2, color);
    
    if((y1 < y2) && (x1 != x2))			// fill block
    { 
        for(i = y1+1; i <= y2-1; i++)
        TFTLCD_DrawLine(x1+1,i, x2-1,i, fill);
    }
    else if((y1 > y2) && (x1 != x2))
    { 
        for(i = y2+1; i <= y1-1; i++)
        TFTLCD_DrawLine(x1+1,i, x2-1,i, fill);
    }
}

void TFTLCD_DrawCircle(s16 x1, s16 y1, s16 r, u16 color)	/* draw a circle */
{
    int x, y;
    float s;
    
    for(y = y1 - r*3/4; y <= y1 + r*3/4; y++)	// draw with y variable
    { 
        s = sqrt((long)r*(long)r - (long)(y-y1)*(long)(y-y1)) + 0.5;
        x = x1 + (int)s;
        TFTLCD_DrawPixel(x, y, color);
        x = x1 - (int)s;
        TFTLCD_DrawPixel(x, y, color);
    }
    
    for(x = x1 - r*3/4; x <= x1 + r*3/4; x++)	// draw with x variable
    { 
        s = sqrt((long)r*(long)r - (long)(x-x1)*(long)(x-x1)) + 0.5;
        y = y1 + (int)s;
        TFTLCD_DrawPixel(x, y, color);
        y = y1 - (int)s;
        TFTLCD_DrawPixel(x, y, color);
    }
}

void TFTLCD_DrawImage(u16 xStart,u16 yStart,u16 xSize,u16 ySize, const u16 *buffer)
{       
    u16 x, y, index = 0;

    TFTLCD_SetAddr(xStart,yStart,xStart+xSize-1,yStart+ySize-1);    
    
    for(y=0; y<ySize; y++)                                                    
    {
        for(x=0; x<xSize; x++)
            TFTLCD_WriteRam(buffer[index++]);
    }
}

/*****************************************************************************
* Descriptions  : ��������Ʈ�� �ϼ�����Ʈ ���ۿ� ����.
* Parameters    : ��������Ʈ �ڵ�, ��Ʈ����
* Return Value  : None
*****************************************************************************/
static void GetFontBuffer(u16 code, u8 *FontBuffer)
{
	unsigned char i;
	unsigned char cho_5bit, joong_5bit, jong_5bit;
	unsigned char cho_bul, joong_bul, jong_bul=0, jong_flag;
	unsigned short ch;

	cho_5bit = table_cho[(code >> 10) & 0x001F];		// �ʼ�: 14-10 5bit�� ����
	joong_5bit = table_joong[(code >> 5) & 0x001F];	    // �߼�: 09-05 5bit�� ����
	jong_5bit = table_jong[code & 0x001F];				// ����: 04-00 5bit�� ����

	if(jong_5bit == 0) // ������ ������
	{
		jong_flag = 0;
		cho_bul = bul_cho1[joong_5bit];
		if((cho_5bit == 1) || (cho_5bit == 16))			// 1: Fill Code, 16: ��
			joong_bul = 0;
		else
			joong_bul = 1;
    }
	else // ������ ������
    {
		jong_flag = 1;
		cho_bul = bul_cho2[joong_5bit];
		if((cho_5bit == 1) || (cho_5bit == 16))
			joong_bul = 2;
		else
			joong_bul = 3;
		jong_bul = bul_jong[joong_5bit];
	}

	//----------------------- ��Ʈ�� ���۷� ����---------------------------
	ch = cho_bul*20 + cho_5bit;			        // �ʼ� ��Ʈ ���� 
	for(i = 0; i < 32; i++)
	    FontBuffer[i] = Font16x16Kor[ch][i];

	ch = 8*20 + joong_bul*22 + joong_5bit;	    // �߼� ��Ʈ�� OR
	for(i = 0; i < 32; i++)
	    FontBuffer[i] |= Font16x16Kor[ch][i];
	    
	if(jong_flag)					            // ������ �����ϸ� OR
    {
		ch = 8*20 + 4*22 + jong_bul*28 + jong_5bit;
		for(i = 0; i < 32; i++)
			FontBuffer[i] |= Font16x16Kor[ch][i];
    }
}

/*****************************************************************************
* Descriptions  : �ϼ�����Ʈ �ڵ带 ����������Ʈ �ڵ�� ��ȯ.
* Parameters    : �ϼ�����Ʈ �ڵ�
* Return Value  : None
*****************************************************************************/
static u16 KsToKssm(u16 code)
{
	u8  high,low;
	u16 index;

    high = code>>8;
    low = code;

	index = ((u16)high - 0xB0) * 94 + low - 0xA1;
	return KSTable[index][0] * 256 + KSTable[index][1];
}

u16 UniToKssm(u16 unicode)
{
    u8 cho, jung, jong;               // �ʼ�, �߼�(joong�� jong�� ȥ�� ������ ���� jung���� ǥ��), ����  
    u16 uni_value;
    u16 kssm;                                 // ������ �ѱ� �����

    uni_value = unicode - 0xAC00;                // �����ڵ� '��'�� �ش��ϴ� ���� ����.

    /* �ʼ�, �߼�, ���� �и�  */
    jong = uni_value % 28;
    jung = ((uni_value - jong) / 28 ) % 21;
    cho = ((uni_value - jong) / 28 ) / 21;

    /* �ʼ� �߼� ���� ������ �ڸ� ������ ��ȯ  */

    cho += 2;                            // �ʼ��� �������� ��� �����ڵ庸�� �������� 2���� ũ��.

    // �߼��� ��� �ش� �������� �߰����� ����� �����Ƿ� ���� ǥ�� �����Ͽ� �������� �޸� �����ش�.
    if(jung < 5) jung += 3;
    else if(jung < 11) jung += 5;
    else if(jung < 17) jung += 7;
    else jung += 9;

    // ������ ��� ���� �߼�ó�� ǥ�� �����Ͽ� �������� �޸� ���� �ش�.
    if(jong < 17) jong++;
    else jong += 2;

    /* ������ �ѱ۷� ��ȯ */

    // MSB�� 1�� ��� �ѱ��̹Ƿ� 0x8000
    kssm = 0x8000 | (cho << 10) | ( jung<<5) | jong;

    return kssm;
}


/*****************************************************************************
* Descriptions  : TFT LCD�� �ѱ� �ϼ�����Ʈ�� ǥ��.
* Parameters    : ǥ����ǥ(x,y), �ϼ����ڵ�, ��Ʈ����, ������
* Return Value  : None
*****************************************************************************/
static void TFTLCD_PutCharKor(u16 x, u16 y, u16 code, u16 color, u16 BgColor)
{
	s16 i, j;
    u8 FontBuffer[32];

    TFTLCD_SetAddr(x, y, x+15, y+15);
	GetFontBuffer(code,FontBuffer);
        
	for(i=0; i<32; i++)
	{
		for(j=7; j>=0; j--)
		{
            if(FontBuffer[i] & (1<<j)) TFTLCD_WriteRam(color);
            else TFTLCD_WriteRam(BgColor);                                                                  
		}
	}	    
}

/*****************************************************************************
* Descriptions  : TFT LCD�� ASCII��Ʈ�� ǥ��.
* Parameters    : ǥ����ǥ(x,y), ASCII�ڵ�, ��Ʈ����, ������
* Return Value  : None
*****************************************************************************/
static void TFTLCD_PutCharEng(u16 x, u16 y, u8 ascii, u16 color, u16 BgColor)
{
	s16 i, j;               

    TFTLCD_SetAddr(x, y, x+7, y+15);
    
    for(i=0; i<16; i++)
    {
        for(j=7; j>=0; j--)
        {
            if(Font8x16Ascii[ascii][i] & (1<<j)) TFTLCD_WriteRam(color);
            else TFTLCD_WriteRam(BgColor);         
        }
    }    
}

/*****************************************************************************
* Descriptions  : TFT LCD�� ���ڿ��� ǥ��.
* Parameters    : ǥ����ǥ(x,y), ��Ʈ����, ������, ���ڿ�
* Return Value  : None
*****************************************************************************/
void TFTLCD_PutStr(u16 x, u16 y, u16 color, u16 BgColor, char *string)
{    
    u8  EngChar;
    u16 KorChar;
    
    x *= 8;
    y *= 16;
    
	while(*string != '\0')
    {                
        // ������ ���
        if(*string<0x80)
        {
            EngChar = *(string++);
            TFTLCD_PutCharEng(x, y, EngChar, color, BgColor);
            x += 8;
        }    
        // �ѱ��� ���
        else
        {
            KorChar = *(string++)<<8;
            KorChar |= *(string++);
          
            TFTLCD_PutCharKor(x, y, KsToKssm(KorChar), color, BgColor);     
            x += 16;
        }
    }    
}

/*****************************************************************************
* Descriptions  : TFT LCD�� ���ڿ��� printf������� ǥ��.
* Parameters    : ǥ����ǥ(x,y), ��Ʈ����, ������, ���ڿ�+����
* Return Value  : None
*****************************************************************************/
void TFTLCD_printf(u16 x, u16 y, u16 FontColor, u16 BgColor, const char *fmt,...)
{
	char string[256];
	va_list ap;

	va_start(ap,fmt);
	vsprintf(string,fmt,ap);
	va_end(ap);

	TFTLCD_PutStr(x, y, FontColor, BgColor, string);
}

void TFTLCD_DrawBitmap(u32 sector, u16 x, u16 y)
{                   
    BITMAP_HEADER* pBmpHeader;
	u8  buffer[512];
	u16 pixel;
    u8  BmpControl;
    u32 SectorNum, StartPixel, SectorCnt, i;
	
    SD_ReadBlock(buffer, (sector++)<<9, 512);   
    SD_WaitReadOperation();
    while(SD_GetStatus() != SD_TRANSFER_OK);
    
    pBmpHeader = (BITMAP_HEADER*)buffer;
    StartPixel = pBmpHeader->bfOffBits;    
    
    // ��ü �������϶� �̹��� ǥ�� ���
/*    if(pBmpHeader->biWidth==MAX_LCD_WIDTH && pBmpHeader->biHeight==MAX_LCD_HEIGHT)      
    {
        TFTLCD_XmirrLandscape();
        TFTLCD_SetAddr(x, y, x+pBmpHeader->biWidth-1,y+pBmpHeader->biHeight-1);        
    }
    else if(pBmpHeader->biWidth==MAX_LCD_HEIGHT && pBmpHeader->biHeight==MAX_LCD_WIDTH) 
    {
        TFTLCD_Portrait();        
        TFTLCD_SetAddr(x, y, x+pBmpHeader->biWidth-1,y+pBmpHeader->biHeight-1);        
    }    */

        TFTLCD_XmirrLandscape();
        TFTLCD_SetAddr(x, y, x+pBmpHeader->biWidth-1,y+pBmpHeader->biHeight-1);        
        
    // 16bit bitmap�� ���
    if(pBmpHeader->biBitCount == 16) 
    {   
        SectorNum = (pBmpHeader->biWidth)*(pBmpHeader->biHeight)*2/512;      
        for(i=StartPixel; i<512; i+=2)
            TFTLCD_WriteRam((u16)buffer[i]|buffer[i+1]<<8);	       
        
        for(SectorCnt=0; SectorCnt<SectorNum; SectorCnt++)
        {           
            SD_ReadBlock(buffer, (sector++)<<9, 512);             
            SD_WaitReadOperation();
            while(SD_GetStatus() != SD_TRANSFER_OK);               
            if(SectorCnt==299)
            {
                for(i=0;i<StartPixel;i+=2)
                    TFTLCD_WriteRam((u16)buffer[i]|buffer[i+1]<<8);	       
            }     
            else         
            {
                for(i=0;i<512;i+=2)
                    TFTLCD_WriteRam((u16)buffer[i]|(u16)buffer[i+1]<<8);
            }	        
        }
    }        
    // 24bit bitmap�� ���
    else if(pBmpHeader->biBitCount == 24)         
    {      
        SectorNum = (pBmpHeader->biWidth)*(pBmpHeader->biHeight)*3/512;
      
        for(i=StartPixel; i<510; i+=3)
        {        
            pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                    
            TFTLCD_WriteRam(pixel);
        }          
        
        BmpControl = 1;
        for(SectorCnt=0; SectorCnt<SectorNum; SectorCnt++)
        {
            switch(BmpControl)
            {
                case 1:
                    pixel  = (buffer[510] & 0xF8) >> 3;
                    pixel |= (buffer[511] & 0xFC) << 3;
                    SD_ReadBlock(buffer, (sector++)<<9, 512);                     
                    SD_WaitReadOperation();
                    while(SD_GetStatus() != SD_TRANSFER_OK);                       
                    pixel |= (buffer[0] & 0xF8) << 8;                   
                    TFTLCD_WriteRam(pixel);   

                    for(i=1; i<511; i+=3)
                    {        
                        pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                   
                        TFTLCD_WriteRam(pixel);   
                    }
                    BmpControl = 2;                
                    break;    
                case 2:
                    pixel = (buffer[511] & 0xF8) >> 3;                    
                    SD_ReadBlock(buffer, (sector++)<<9, 512);    
                    SD_WaitReadOperation();
                    while(SD_GetStatus() != SD_TRANSFER_OK);                       
                    pixel |= (buffer[0] & 0xFC) << 3;
                    pixel |= (buffer[1] & 0xF8) << 8;                    
                    TFTLCD_WriteRam(pixel);

                    for(i=2; i<512; i+=3)
                    {        
                        pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                  
                        TFTLCD_WriteRam(pixel);   
                    }
                    BmpControl = 3;                 
                    break;        
                case 3:
                    SD_ReadBlock(buffer, (sector++)<<9, 512);                     
                    SD_WaitReadOperation();
                    while(SD_GetStatus() != SD_TRANSFER_OK);                                   
                    
                    if(SectorCnt==SectorNum-1)
                    {
                        for(i=0;i<StartPixel;i+=3)            
                        {    
                            pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                     
                            TFTLCD_WriteRam(pixel);   
                        }    
                    }
                    else
                    {
                        for(i=0; i<510; i+=3)            
                        {    
                            pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                        
                            TFTLCD_WriteRam(pixel);   
                        }                       
                    }    
                    BmpControl = 1;                     
                    break;                  
            }
        }              
    }     
}

void SRAM_CopyColor(u32 address, int xSize, int ySize, u16 color)
{
    int i;
    uint32_t WriteAddr = address;
    int size = (xSize*ySize)>>3;
    
    for(i=0; i<size; i++)
    {
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = color;     
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 2) = color;     
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 4) = color;     
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 6) = color;     
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 8) = color;     
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 10) = color;     
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 12) = color;     
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 14) = color;          
        WriteAddr += 16;
    }
}

void SRAM_CopyImage(u32 BgAddr, u32 CopyAddr, int xSize, int ySize)
{
    int i;
    uint32_t WriteAddr = CopyAddr; 
    uint32_t ReadAddr = BgAddr;
    int size = (xSize*ySize)>>3;
    uint16_t buffer[8];
                       
    for(i=0; i<size; i++)
    {             
        buffer[0] = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr); 
        buffer[1] = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 2);
        buffer[2] = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 4);
        buffer[3] = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 6);
        buffer[4] = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 8);
        buffer[5] = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 10);
        buffer[6] = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 12);
        buffer[7] = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 14);
        
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = buffer[0];
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 2) = buffer[1];
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 4) = buffer[2];
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 6) = buffer[3];
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 8) = buffer[4];
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 10) = buffer[5];
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 12) = buffer[6];
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 14) = buffer[7];      
        
     /*   *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr);
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 2) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 2);
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 4) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 4);
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 6) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 6);
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 8) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 8);
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 10) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 10);
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 12) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 12);
        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr + 14) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 14);
        */             
        ReadAddr += 16;
        WriteAddr += 16;        
    }
}

void SRAM_CopySmallImage(u32 BgAddr, u32 CopyAddr, int xStart, int yStart, int xSize, int ySize)
{
    int i, j;
    uint32_t WriteAddr;
    uint32_t ReadAddr = CopyAddr;
              
    for(i=0; i<ySize; i++)
    {
        WriteAddr = BgAddr + xStart*2 + (yStart+i)*1600;        
        for(j=0; j<xSize; j+=8)
        {
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr);     
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr+2) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr+2);   
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr+4) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr+4);   
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr+6) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr+6);   
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr+8) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr+8);   
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr+10) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr+10);   
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr+12) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr+12);   
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr+14) = *(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr+14);           
            ReadAddr += 16;            
            WriteAddr += 16;
        }
    }                  
}


void TFTLCD_DrawSram(int xStart, int yStart, int xSize, int ySize, u32 address)
{
    int i;
    uint32_t ReadAddr = address;
    int size = (xSize*ySize)>>3;
    
    TFTLCD_SetAddr(xStart, yStart, xStart+xSize-1, yStart+ySize-1);
     
    for(i=0; i<size; i++)
    {        
        TFTLCD_WriteRam(*(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr));
        TFTLCD_WriteRam(*(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 2));
        TFTLCD_WriteRam(*(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 4));
        TFTLCD_WriteRam(*(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 6));
        TFTLCD_WriteRam(*(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 8));
        TFTLCD_WriteRam(*(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 10));    
        TFTLCD_WriteRam(*(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 12));  
        TFTLCD_WriteRam(*(__IO uint16_t*) (Bank1_SRAM2_ADDR + ReadAddr + 14));              
        ReadAddr += 16;
    }
}

void SRAM_PutCharEng(long address, int xStart, int yStart, u8 ascii, u16 color)
{
	s16 x,y;        
    int count;
    
    xStart *= 2;
    
    if(ascii >= 0x80) return;
        
    for(y=0;y<16;y++)
    {
        count = 0;        
        for(x=7;x>=0;x--)
        {    
            if(Font8x16Ascii[ascii][y]&(1<<x))
            {                
                SRAM_WriteBuffer(&color, address+xStart+yStart*1280+count, 1);
            }              
            count += 2;            
        }       
        yStart++;
    }
}

void SRAM_PutCharKor(long address, int xStart, int yStart, u16 code,u16 color)
{
	s16 x,y;
    u8 FontBuffer[32];
    int count;
    
    xStart *= 2;
        
	GetFontBuffer(code,FontBuffer);
    
	for(y=0;y<32;y+=2)
	{
        count = 0;         
		for(x=7;x>=0;x--)
		{           
            if(FontBuffer[y]&(1<<x))
            {
                SRAM_WriteBuffer(&color, address+xStart+yStart*1280+count, 1);
            }            
            count += 2;            
		}
        count = 0;         
		for(x=7;x>=0;x--)
		{           
            if(FontBuffer[y+1]&(1<<x))
            {
                SRAM_WriteBuffer(&color, address+xStart+16+yStart*1280+count, 1);
            }            
            count += 2;            
		}                
        yStart++;        
	}	    
}

void SRAM_PutCharEngBg(long address, int xStart, int yStart, u8 ascii, u16 FontColor, u16 BgColor)
{
	s16 x,y;        
    int count;
    
    xStart *= 2;
    
    if(ascii >= 0x80) return;
        
    for(y=0;y<16;y++)
    {
        count = 0;        
        for(x=7;x>=0;x--)
        {    
            if(Font8x16Ascii[ascii][y]&(1<<x))
            {                
                SRAM_WriteBuffer(&FontColor, address+xStart+yStart*1280+count, 1);
            }      
            else
            {                
                SRAM_WriteBuffer(&BgColor, address+xStart+yStart*1280+count, 1);
            }                  
            count += 2;            
        }       
        yStart++;
    }
}

void SRAM_PutCharKorBg(long address, int xStart, int yStart, u16 code, u16 FontColor, u16 BgColor)
{
	s16 x,y;
    u8 FontBuffer[32];
    int count;
    
    xStart *= 2;
        
	GetFontBuffer(code,FontBuffer);
    
	for(y=0;y<32;y+=2)
	{
        count = 0;         
		for(x=7;x>=0;x--)
		{           
            if(FontBuffer[y]&(1<<x))
            {
                SRAM_WriteBuffer(&FontColor, address+xStart+yStart*1280+count, 1);
            }            
            else
            {
                SRAM_WriteBuffer(&BgColor, address+xStart+yStart*1280+count, 1);
            }
            count += 2;            
		}
        count = 0;         
		for(x=7;x>=0;x--)
		{           
            if(FontBuffer[y+1]&(1<<x))
            {
                SRAM_WriteBuffer(&FontColor, address+xStart+16+yStart*1280+count, 1);
            }            
            else
            {
                SRAM_WriteBuffer(&BgColor, address+xStart+16+yStart*1280+count, 1);                
            }
            count += 2;            
		}                
        yStart++;        
	}	    
}

void SRAM_CopyFontBg(long address, u16 x1, u16 y1, u16 x2, char *pStr, u16 FontColor, u16 BgColor)
{
    u8  EngChar;
    u16 KorChar;  
                
	while(*pStr != '\0')
    {                
        // ������ ���
        if(*pStr<0x80)
        {    
            EngChar = *(pStr++);          
                
            if(x1 < LCD_WIDTH_SIZE) SRAM_PutCharEngBg(address, x1, y1, EngChar, FontColor, BgColor);    
            x1 += 8;            
        }
        // �ѱ��� ���
        else
        {
            KorChar = (*(pStr++))<<8;
            KorChar |= *(pStr++);
          
            if(x1 < LCD_WIDTH_SIZE) SRAM_PutCharKorBg(address, x1, y1, KsToKssm(KorChar), FontColor, BgColor);     
            x1 += 16;              
        }
        if(x1 > x2) break;
    }           
}

void SRAM_CopyFont(long address, u16 x1, u16 y1, u16 x2, char *pStr, u16 color)
{
    u8  EngChar;
    u16 KorChar;  
    u16 x = x1, y = y1;
                    
	while(*pStr != '\0')
    {                
        // ������ ���
        if(*pStr<0x80)
        {    
            EngChar = *(pStr++);          
                
            if(x < 800) SRAM_PutCharEng(address, x, y, EngChar, color);    
            x += 8;            
        }
        // �ѱ��� ���
        else
        {
            KorChar = (*(pStr++))<<8;
            KorChar |= *(pStr++);
          
            if(x < 800) SRAM_PutCharKor(address, x, y, KsToKssm(KorChar), color);     
            x += 16;              
        }
        if(x > x2) 
        {
            y += 16;
            x = x1;
        }
        else if(x > x2*2) break;
    }           
}

void SRAM_CopyFontUni(long address, u16 xStart, u16 yStart, u8 *pStr, u16 color)
{    
    u8  EngChar;
    u16 KorChar;
        
	while(*pStr != '\0')
    {                
        // ������ ���
        if(*pStr<0x80)
        {    
            EngChar = *(pStr++);          
            pStr++;
                
            if(xStart < LCD_WIDTH_SIZE) SRAM_PutCharEng(address, xStart, yStart, EngChar, color);                       
            xStart += 8;
        }
        // �ѱ��� ���
        else
        {
            KorChar = (*(pStr++))<<8;
            KorChar |= *(pStr++);
          
            if(xStart < LCD_WIDTH_SIZE) SRAM_PutCharKor(address, xStart, yStart, UniToKssm(KorChar), color);     
            xStart += 16;               
        }
    }    
}

void SRAM_DrawImage(u32 address, int xStart, int yStart, int xSize, int ySize, const u16 *buffer)
{       
    u16 x, y, index = 0;
    uint32_t WriteAddr;    
    
    xStart *= 2;
    for(y=0; y<ySize; y++)                                                    
    {
        WriteAddr = address + xStart + yStart*1280 + y*1280;        
        for(x=0; x<xSize; x++)
        {
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = buffer[index++];            
            WriteAddr += 2;
        }              
    }
}

void SRAM_CopyBitmap(u32 sector, u32 address)
{
    BITMAP_HEADER* pBmpHeader;
	u8  buffer[512];
	u16 pixel;
    u8  BmpControl;
    u32 SectorNum, StartPixel, SectorCnt, i;
    uint32_t WriteAddr = address;
    
    SD_ReadBlock(buffer, (sector++)<<9, 512);
    SD_WaitReadOperation();
    while(SD_GetStatus() != SD_TRANSFER_OK);          
    
    pBmpHeader = (BITMAP_HEADER *)buffer;
    StartPixel = pBmpHeader->bfOffBits;      
                     
    // 24bit bitmap�� ���
    if(pBmpHeader->biBitCount == 24)         
    {      
        SectorNum = (pBmpHeader->biWidth)*(pBmpHeader->biHeight)*3/512;
        
        for(i=StartPixel; i<510; i+=3)
        {        
            pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                     
            *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = pixel;                             
            WriteAddr += 2;                
        }          
        
        BmpControl = 1;    
        for(SectorCnt=0; SectorCnt<SectorNum; SectorCnt++)
        {
            switch(BmpControl)
            {
            case 1:
                pixel  = (buffer[510] & 0xF8) >> 3 | (buffer[511] & 0xFC) << 3;
                SD_ReadBlock(buffer, (sector++)<<9, 512);     
                SD_WaitReadOperation();
                while(SD_GetStatus() != SD_TRANSFER_OK);          
                pixel |= (buffer[0] & 0xF8) << 8;               
                *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = pixel;                             
                WriteAddr += 2;

                for(i=1; i<511; i+=3)
                {        
                    pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                                  
                    *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = pixel;                             
                    WriteAddr += 2;                   
                }
                BmpControl = 2;                
                break;        
            case 2:
                pixel = (buffer[511] & 0xF8) >> 3;                    
                SD_ReadBlock(buffer, (sector++)<<9, 512);                     
                SD_WaitReadOperation();
                while(SD_GetStatus() != SD_TRANSFER_OK);                          
                pixel |= (buffer[0] & 0xFC) << 3 | (buffer[1] & 0xF8) << 8;
                *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = pixel;                             
                WriteAddr += 2;
                               
                for(i=2; i<512; i+=3)
                {        
                    pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                              
                    *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = pixel;                             
                    WriteAddr += 2;    
                }
                BmpControl = 3;                 
                break;                 
            case 3:
                SD_ReadBlock(buffer, (sector++)<<9, 512);                     
                SD_WaitReadOperation();
                while(SD_GetStatus() != SD_TRANSFER_OK);          
                                
                if(SectorCnt==SectorNum-1)
                {
                    for(i=0; i<StartPixel; i+=3)            
                    {    
                        pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                                   
                        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = pixel;                             
                        WriteAddr += 2;   
                    }    
                }
                else
                {
                    for(i=0; i<510; i+=3)            
                    {    
                        pixel = (buffer[i]&0x0F8)>>3 | (buffer[i+1]&0x0FC)<<3 | (buffer[i+2]&0x0F8)<<8;                 
                        *(uint16_t *) (Bank1_SRAM2_ADDR + WriteAddr) = pixel;                             
                        WriteAddr += 2;             
                    }                       
                }    
                BmpControl = 1;                     
                break;                                     
            }
        } 
    }         
}