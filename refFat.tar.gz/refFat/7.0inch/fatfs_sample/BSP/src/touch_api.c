/*****************************************************************************
* Copyright(C) 2013 Dong-A University MICCA
* All right reserved.
*
* File name	    : touch_api.c
* Last version	: V1.00
* Description	: This file is source file for touch screen function.
*
* History
* Date		    Version	    Author			Description
* 2013/05/01	1.00		oh woomin	    Created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "delay.h"
#include "platform_config.h"
#include "typedef.h"
#include "ar1020.h"
#include "tftlcd.h"
#include "rgb_color_table.h"

/* Private define ------------------------------------------------------------*/
#define ENABLE_TOUCH            0x12
#define DISABLE_TOUCH           0x13
#define CALIBRATE_MODE          0x14
#define REG_READ                0x20
#define REG_WRITE               0x21
#define REG_START_ADDR_REQ      0x22
#define REG_WRITE_EEPROM        0x23
#define EEPROM_READ             0x28
#define EEPROM_WRITE            0x29
#define EEPROM_WRITE_TO_REG     0x2B

#define CALIBRATE_RESOL         4096
#define CALIBRATE_INSET         512  

#define GET_POINT_X(x)          ((x)*LCD_WIDTH_SIZE/4096)
#define GET_POINT_Y(y)          ((y)*LCD_HEIGHT_SIZE/4096)

/* Private variables ---------------------------------------------------------*/
static POINT DispPoint;

/*****************************************************************************
* Descriptions  : Initialize the touch screen
* Parameters    : None
* Return Value  : None
*****************************************************************************/
void TouchConfig(void)
{
    AR1020_Init();
}

/*****************************************************************************
* Descriptions  : Enable touch
* Parameters    : None
* Return Value  : error status
*****************************************************************************/
ErrorStatus EnableTouch(void)
{
    u8 buffer[4];
    
    buffer[0] = 0x00;
    buffer[1] = 0x55;
    buffer[2] = 0x01;
    buffer[3] = ENABLE_TOUCH;
    
    if(AR1020_Write(AR1020_ADDR, 4, buffer) == ERROR)
        return ERROR;   
    while(!(AR1020_IRQ_PORT->IDR & AR1020_IRQ_BIT));    
    if(AR1020_Read(AR1020_ADDR, 4, buffer) == ERROR)
        return ERROR;
    
    TFTLCD_printf(DispPoint.x, DispPoint.y, RGB_GRAY, RGB_WHITE,
                  "Enable Touch: (0x%02x 0x%02x 0x%02x 0x%02x)",
                  buffer[0], buffer[1], buffer[2], buffer[3]);
    DispPoint.y++;
    
    return SUCCESS;
}

/*****************************************************************************
* Descriptions  : Disable touch
* Parameters    : None
* Return Value  : error status
*****************************************************************************/
ErrorStatus DisableTouch(void)
{
    u8 buffer[4];
    
    buffer[0] = 0x00;
    buffer[1] = 0x55;
    buffer[2] = 0x01;
    buffer[3] = DISABLE_TOUCH;
    
    if(AR1020_Write(AR1020_ADDR, 4, buffer) == ERROR)
        return ERROR;   
    while(!(AR1020_IRQ_PORT->IDR & AR1020_IRQ_BIT));    
    if(AR1020_Read(AR1020_ADDR, 4, buffer) == ERROR)
        return ERROR;
    
    TFTLCD_printf(DispPoint.x, DispPoint.y, RGB_GRAY, RGB_WHITE,
                  "Disable Touch: (0x%02x 0x%02x 0x%02x 0x%02x)",
                  buffer[0], buffer[1], buffer[2], buffer[3]);
    DispPoint.y++;
    
    return SUCCESS;
}

/*****************************************************************************
* Descriptions  : Calibrate mode
* Parameters    : None
* Return Value  : error status
*****************************************************************************/
ErrorStatus CalibrateTouch(void)
{
    int i;
    u8 buffer[5];
    POINT point[4] = {{GET_POINT_X(CALIBRATE_INSET), GET_POINT_Y(CALIBRATE_INSET)},
                    {GET_POINT_X(CALIBRATE_RESOL-CALIBRATE_INSET), GET_POINT_Y(CALIBRATE_INSET)},
                    {GET_POINT_X(CALIBRATE_RESOL-CALIBRATE_INSET), GET_POINT_Y(CALIBRATE_RESOL-CALIBRATE_INSET)},
                    {GET_POINT_X(CALIBRATE_INSET), GET_POINT_Y(CALIBRATE_RESOL-CALIBRATE_INSET)}};
    
    buffer[0] = 0x00;
    buffer[1] = 0x55;
    buffer[2] = 0x02;
    buffer[3] = CALIBRATE_MODE;
    buffer[4] = 0x04;
    
    if(AR1020_Write(AR1020_ADDR, 5, buffer) == ERROR)
        return ERROR;      
    while(!(AR1020_IRQ_PORT->IDR & AR1020_IRQ_BIT));    
    if(AR1020_Read(AR1020_ADDR, 4, buffer) == ERROR)
        return ERROR;    
    TFTLCD_printf(DispPoint.x, DispPoint.y, RGB_GRAY, RGB_WHITE,
                  "Calibrate Mode: (0x%02x 0x%02x 0x%02x 0x%02x)",
                  buffer[0], buffer[1], buffer[2], buffer[3]);
    DispPoint.y++;
    
    for(i=0; i<4; i++)
    {
        TFTLCD_DrawLine(point[i].x-16, point[i].y, point[i].x+16, point[i].y, RGB_RED);
        TFTLCD_DrawLine(point[i].x, point[i].y-16, point[i].x, point[i].y+16, RGB_RED);
        TFTLCD_DrawRect(point[i].x-12, point[i].y-12, point[i].x+12, point[i].y+12, RGB_RED);
        
        while(!(AR1020_IRQ_PORT->IDR & AR1020_IRQ_BIT));
        if(AR1020_Read(AR1020_ADDR, 4, buffer) == ERROR)
            return ERROR;
        
        TFTLCD_DrawLine(point[i].x-16, point[i].y, point[i].x+16, point[i].y, RGB_WHITE);
        TFTLCD_DrawLine(point[i].x, point[i].y-16, point[i].x, point[i].y+16, RGB_WHITE);
        TFTLCD_DrawRect(point[i].x-12, point[i].y-12, point[i].x+12, point[i].y+12, RGB_WHITE);        
    }        
        
    return SUCCESS;    
}

/*****************************************************************************
* Descriptions  : Calibrate the touch screen point
* Parameters    : None
* Return Value  : error status
*****************************************************************************/
ErrorStatus CalibratePoint(void)
{
    DispPoint.x = 32; DispPoint.y = 4;         
    TFTLCD_Color(0, 0, LCD_WIDTH_SIZE , LCD_HEIGHT_SIZE, RGB_WHITE);    
    TFTLCD_printf(DispPoint.x, DispPoint.y, RGB_ORANGE, RGB_WHITE, "Touch Screen Calibration");    
    DispPoint.y += 2;

    if(DisableTouch() == ERROR)
        return ERROR; 
    if(CalibrateTouch() == ERROR)
        return ERROR;  
    delay_ms(1000);     
    if(EnableTouch() == ERROR)
        return ERROR;
    delay_ms(1000);       
    
    TFTLCD_Color(0, 0, LCD_WIDTH_SIZE , LCD_HEIGHT_SIZE, RGB_WHITE);    
    
    return SUCCESS;
}

/*****************************************************************************
* Descriptions  : Get touch screen point(touch point)
* Parameters    : slave addr, display point(x,y), pen
* Return Value  : error status
*****************************************************************************/
ErrorStatus GetTouchPoint(u8 address, u16 *x, u16 *y, u8 *pen)
{
    u8 buffer[5];
    
    if(!(AR1020_IRQ_PORT->IDR & AR1020_IRQ_BIT)) 
        return ERROR;

    AR1020_Read(AR1020_ADDR, 5, buffer);
    
    *pen = buffer[0] & 0x01;
    *x = buffer[1] | buffer[2]<<7;
    *y = buffer[3] | buffer[4]<<7;
    
    return SUCCESS;
}

/*****************************************************************************
* Descriptions  : Get touch screen point(display point)
* Parameters    : display point(x,y)
* Return Value  : error status
*****************************************************************************/
ErrorStatus GetDisplayPoint(u16 *x, u16 *y)
{
    u8 pen;
    
    if(GetTouchPoint(AR1020_ADDR, x, y, &pen) == ERROR)
        return ERROR;
    
    *x = GET_POINT_X(*x);
    *y = GET_POINT_Y(*y);

    return SUCCESS;
}
