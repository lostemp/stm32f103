/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : stm32_uart.c
* Last version	: V2.00
* Description	: This file is source file for uart function.
*
* History
* Date		    Version	    Author			Description
* 2011/03/06	2.00		oh woomin	    V2.00 created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <stdarg.h>
#include <stdio.h>
#include "stm32f4xx.h"
#include "stm32_uart.h"
#include "queue.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
QueueType Uart1RxQueue, Uart3RxQueue;
QueueType Uart1TxQueue, Uart3TxQueue;

/* Private function prototypes -----------------------------------------------*/
#ifdef __GNUC__
  /* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

/*****************************************************************************
* Descriptions  : Retargets the C library printf function to the USART.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
PUTCHAR_PROTOTYPE
{
    /* Place your implementation of fputc here */
    /* e.g. write a character to the USART */
	if (ch == '\n')
    {
        USART_SendData(USART1, '\r');
        /* Loop until the end of transmission */
        while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);        
    }
    USART_SendData(USART1, (uint8_t) ch);    
    /* Loop until the end of transmission */
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);    

    return ch;    
}

/*****************************************************************************
* Descriptions  : Initialize the UART port.
* Parameters    : Port, Baudrate
* Return Value  : None
*****************************************************************************/
void UART_Init(u8 uart, u32 baud)
{
    USART_InitTypeDef USART_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure; 
    NVIC_InitTypeDef NVIC_InitStructure;   
    
    if(uart == UART1)
    {   
        /* Enable USART1 clock */
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
        /* Enable GPIO clock */        
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);         
                            
        /* Connect PXx to USART1_Tx*/
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_USART1);        
        /* Connect PXx to USART1_Rx*/
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_USART1);

        /* Enable the USART1 Interrupt */
        NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;    
        NVIC_Init(&NVIC_InitStructure);   
        
        /* Configure USART1 Tx as alternate function  */
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        
        /* Configure USART1 Rx as alternate function  */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
        GPIO_Init(GPIOB, &GPIO_InitStructure);                                        
    }
    else if(uart == UART3)
    { 
        /* Enable USART1 clock */
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
        /* Enable GPIO clock */        
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);         
                            
        /* Connect PXx to USART1_Tx*/
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3);        
        /* Connect PXx to USART1_Rx*/
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3);

        /* Enable the USART3 Interrupt */
        NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;    
        NVIC_Init(&NVIC_InitStructure);  
        
        /* Configure USART1 Tx as alternate function  */
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        
        /* Configure USART1 Rx as alternate function  */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
        GPIO_Init(GPIOB, &GPIO_InitStructure);          
    }
   
    /* 
        USARTx configured as follow:
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
    */    
    USART_InitStructure.USART_BaudRate = baud;                                      
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;                    
    USART_InitStructure.USART_StopBits = USART_StopBits_1;                          
    USART_InitStructure.USART_Parity = USART_Parity_No;                             
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                 
    
    if(uart == UART1)
    {   
        /* Configure USART1 */             
        USART_Init(USART1, &USART_InitStructure);
        /* Enable the USART1 */              
        USART_Cmd(USART1, ENABLE);	         
        /* Enable USART1 Receive interrupt */
        USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);            
    }
    else if(uart == UART3)
    {                           
        /* Configure USART3 */             
        USART_Init(USART3, &USART_InitStructure);
        /* Enable the USART3 */              
        USART_Cmd(USART3, ENABLE);	         
        /* Enable USART3 Receive interrupt */
        USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);            
    }
}

/*****************************************************************************
* Descriptions  : UART1���� 1���� ���
* Parameters    : 1byte ����(ascii code)
* Return Value  : ���� ���� ��ȯ (SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART1_PutChar(char ch)
{    
	if (ch == '\n')
    {
        if(enqueue(&Uart1TxQueue, '\r') != QUEUE_SUCCESS)
        {            
            return ERROR;        
        }                       
    }
    if(enqueue(&Uart1TxQueue, ch) != QUEUE_SUCCESS)
    {            
        return ERROR;        
    }               
    USART_ITConfig(USART1, USART_IT_TXE, ENABLE);
    
    return SUCCESS;            
}

/*****************************************************************************
* Descriptions  : UART1���� ���Ź��ۿ��� 1���� ��������
* Parameters    : ��ȯ�� ����
* Return Value  : ���� ���� ��ȯ(SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART1_GetChar(char *ch)
{          
    if(dequeue(&Uart1RxQueue, (unsigned char *)ch) == QUEUE_SUCCESS) 
        return SUCCESS;
    else 
        return ERROR;
}

/*****************************************************************************
* Descriptions  : UART1���� ���ڿ� ���
* Parameters    : ����� ���ڿ�
* Return Value  : None
*****************************************************************************/
void UART1_PutStr(char *string)
{
	while(*string != '\0') UART1_PutChar(*(string++));
}

/*****************************************************************************
* Descriptions  : UART1���� printf ���
* Parameters    : printf ����
* Return Value  : None
*****************************************************************************/
void UART1_printf(const char *fmt,...)
{
	char string[256];
	va_list ap;

	va_start(ap,fmt);
	vsprintf(string,fmt,ap);
	va_end(ap);

	UART1_PutStr(string);
}

