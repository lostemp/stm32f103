
/* Includes ----------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include "typedef.h"
#include "ff.h"
#include "fatfs_api.h"
#include "stm32_uart.h"

/* Privated variables ------------------------------------------------------*/

DWORD get_fattime (void)
{
	DWORD res;
	
	res = 0;

	return res;
}

void put_rc(FRESULT rc)
{  
	const char *str =
		"OK\0" "DISK_ERR\0" "INT_ERR\0" "NOT_READY\0" "NO_FILE\0" "NO_PATH\0"
		"INVALID_NAME\0" "DENIED\0" "EXIST\0" "INVALID_OBJECT\0" "WRITE_PROTECTED\0"
		"INVALID_DRIVE\0" "NOT_ENABLED\0" "NO_FILE_SYSTEM\0" "MKFS_ABORTED\0" "TIMEOUT\0"
		"LOCKED\0" "NOT_ENOUGH_CORE\0" "TOO_MANY_OPEN_FILES\0";
	FRESULT i;

	for (i = 0; i != rc && *str; i++) {
		while (*str++) ;
	}
    UART1_printf("rc=%u FR_%s\n", (UINT)rc, str);
}

int xatoi (			/* 0:Failed, 1:Successful */
	char **str,		/* Pointer to pointer to the string */
	long *res		/* Pointer to the valiable to store the value */
)
{
	unsigned long val;
	unsigned char c, r, s = 0;


	*res = 0;

	while ((c = **str) == ' ') (*str)++;	/* Skip leading spaces */

	if (c == '-') {		/* negative? */
		s = 1;
		c = *(++(*str));
	}

	if (c == '0') {
		c = *(++(*str));
		switch (c) {
		case 'x':		/* hexdecimal */
			r = 16; c = *(++(*str));
			break;
		case 'b':		/* binary */
			r = 2; c = *(++(*str));
			break;
		default:
			if (c <= ' ') return 1;	/* single zero */
			if (c < '0' || c > '9') return 0;	/* invalid char */
			r = 8;		/* octal */
		}
	} else {
		if (c < '0' || c > '9') return 0;	/* EOL or invalid char */
		r = 10;			/* decimal */
	}

	val = 0;
	while (c > ' ') {
		if (c >= 'a') c -= 0x20;
		c -= '0';
		if (c >= 17) {
			c -= 7;
			if (c <= 9) return 0;	/* invalid char */
		}
		if (c >= r) return 0;		/* invalid char for current radix */
		val = val * r + c;
		c = *(++(*str));
	}
	if (s) val = 0 - val;			/* apply sign if needed */

	*res = val;
	return 1;
}

void put_dump (const BYTE *buff, DWORD ofs, BYTE cnt)
{
	BYTE i;

	UART1_printf("%08lX:", ofs);

	for(i = 0; i < cnt; i++)
		UART1_printf(" %02X", buff[i]);

	UART1_PutChar(' ');
	for(i = 0; i < cnt; i++)
		UART1_PutChar((buff[i] >= ' ' && buff[i] <= '~') ? buff[i] : '.');

	UART1_PutChar('\n');
}

uint8_t uart_getc (void)
{
    char c;
    
    while(UART1_GetChar(&c) == ERROR); 
    return c;
}

void uart_putc (uint8_t d)
{
    UART1_PutChar(d);
}

void get_line (char *buff, int len)
{
	BYTE c;
	int i = 0;

	for (;;) {
		c = uart_getc();
		if (c == '\r') break;
		if ((c == '\b') && i) {
			i--;
			uart_putc(c);
			continue;
		}
		if (c >= ' ' && i < len - 1) {	/* Visible chars */
			buff[i++] = c;
			uart_putc(c);
		}
	}
	buff[i] = 0;
	uart_putc('\n');
}
