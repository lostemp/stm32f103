/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : delay.c
* Last version	: V1.00
* Description	: This file is polling delay function header file.
*
* History
* Date		    Version	    Author			Description
* 2008/07/07	1.00	    oh woomin	    created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

/* Function prototypes -------------------------------------------------------*/
void delay_us(vu32 nCount);
void delay_ms(vu32 nCount);

