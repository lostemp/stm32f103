/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : stm32_systick.h
* Last version	: V1.00
* Description	: This file is header file for systick timer.
*
* History
* Date		    Version	    Author			Description
* 2011/03/06	1.00		oh woomin	    create
*****************************************************************************/

/* Exported functions --------------------------------------------------------*/
void SystickInit(uint32_t time);
void TimeDelay(uint32_t time);
void DecrementTimingDelay(void);
