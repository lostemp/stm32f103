/*****************************************************************************
* Copyright(C) 2013 Dong-A University MICCA
* All right reserved.
*
* File name	    : touch_api.h
* Last version	: V1.00
* Description	: This file is header file for touch screen function.
*
* History
* Date		    Version	    Author			Description
* 2013/05/01	1.00		oh woomin	    Created
*****************************************************************************/

/* Exported functions --------------------------------------------------------*/
void TouchConfig(void);
ErrorStatus CalibratePoint(void);
ErrorStatus GetDisplayPoint(u16 *x, u16 *y);