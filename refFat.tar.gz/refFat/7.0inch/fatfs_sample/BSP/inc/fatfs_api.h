
#ifndef __FATFS_API_H
#define __FATFS_API_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "ff.h"

/* Exported constants --------------------------------------------------------*/
/* Type declarations ---------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/
DWORD get_fattime (void);
void put_rc(FRESULT rc);
int xatoi (char** str, long* res);

uint8_t uart_getc (void);
void uart_putc (uint8_t d);
void get_line (char *buff, int len);
FRESULT scan_files (char* path);
void put_dump (const BYTE *buff, DWORD ofs, BYTE cnt);

#endif
