/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : tftlcd.h
* Last version	: V1.00
* Description	: This file is header file for TFT LCD(SSD1963) display
*
* History
* Date		    Version	    Author			Description
* 2011/06/13	1.00		oh woomin	    Created
*****************************************************************************/

#ifndef __TFTLCD_H
#define __TFTLCD_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

/* Exported constants --------------------------------------------------------*/
// Maximun size of TFT LCD
#define LCD_WIDTH_SIZE       	        800
#define LCD_HEIGHT_SIZE      	        480

/* Define the STM32F10x hardware depending on the used board */
// TFT LCD backlight 
#define TFTLCD_BL_PERIPH                RCC_AHB1Periph_GPIOA
#define TFTLCD_BL_BIT                   GPIO_Pin_4
#define TFTLCD_BL_PORT                  GPIOA
// TFT LCD reset
#define TFTLCD_RST_PERIPH               RCC_AHB1Periph_GPIOA
#define TFTLCD_RST_BIT                  GPIO_Pin_3
#define TFTLCD_RST_PORT                 GPIOA

/* Exported macro ------------------------------------------------------------*/
// Backlight control
#define TFTLCD_BL_ON()                  (TFTLCD_BL_PORT->BSRRL = TFTLCD_BL_BIT)
#define TFTLCD_BL_OFF()                 (TFTLCD_BL_PORT->BSRRH = TFTLCD_BL_BIT)
#define TFTLCD_RST_HIGH()               (TFTLCD_RST_PORT->BSRRL = TFTLCD_RST_BIT)
#define TFTLCD_RST_LOW()                (TFTLCD_RST_PORT->BSRRH = TFTLCD_RST_BIT)

/* Type declarations ---------------------------------------------------------*/
// Bitmap header   
#pragma pack(1)
typedef struct _BITMAP_HEADER
{
	u16		bfType;             // bitmap�� BM���� ����
	u32		bfSize;             // ���� ��ü ũ��
    u16		bfReserved1;    
	u16		bfReserved2;
	u32		bfOffBits;          // �ȼ� ������ǥ�� �ּ�

	u32		biSize;             // ��� ũ��
	u32		biWidth;            // �̹��� ��
    u32		biHeight;           // �̹��� ����
	u16		biPlanes;           // ������ 1
	u16		biBitCount;         // ��Ʈ��
	u32     biCompression;      // ����Ÿ��
	u32     biSizeImage;        // �̹��� ũ��
	u32     biXpelsPerMeter;    // X�� ���ʹ� �ȼ���
	u32     biYpelsPerMeter;    // Y�� ���ʹ� �ȼ���
	u32     biClrUsed;          // �÷��� ��Ʈ����
	u32     biClrImportant;	    // �÷���
	
}BITMAP_HEADER;
#pragma pack()

/* Exported functions --------------------------------------------------------*/
void TFTLCD_Landscape(void);
void TFTLCD_XmirrLandscape(void);
void TFTLCD_Portrait(void);
void TFTLCD_SetAddr(u16 xStart, u16 yStart, u16 xEnd, u16 yEnd);
void TFTLCD_SetBackLight(u8 data);

void TFTLCD_Init(void);

void TFTLCD_Color(u16 xStart, u16 yStart, u16 xSize, u16 ySize, u16 color);
void TFTLCD_ColorTest(u16 xStart, u16 yStart, u16 xSize, u16 ySize, u8 mode);
void TFTLCD_DrawPixel(u16 x, u16 y, u16 color);
void TFTLCD_DrawPen(u16 x, u16 y, u16 color);
void TFTLCD_DrawLine(s16 x1, s16 y1, s16 x2, s16 y2, u16 color);
void TFTLCD_DrawCircle(s16 x1, s16 y1, s16 r, u16 color);
void TFTLCD_DrawRect(s16 x1, s16 y1, s16 x2, s16 y2, u16 color);
void TFTLCD_DrawRectFill(s16 x1, s16 y1, s16 x2, s16 y2, u16 color, u16 fill);
void TFTLCD_DrawImage(u16 xStart,u16 yStart,u16 xSize,u16 ySize, const u16 *buffer);

void TFTLCD_PutStr(u16 xAxis, u16 yAxis, u16 color, u16 BgColor, char *string);
void TFTLCD_printf(u16 x, u16 y, u16 FontColor, u16 BgColor, const char *fmt,...);

void TFTLCD_DrawSram(int xStart, int yStart, int xSize, int ySize, u32 address);
void TFTLCD_DrawBitmap(u32 sector, u16 x, u16 y);

void SRAM_CopyBitmap(u32 sector, u32 address);
void SRAM_CopyColor(u32 address, int xSize, int ySize, u16 color);
void SRAM_CopyImage(u32 BgAddr, u32 CopyAddr, int xSize, int ySize);
void SRAM_DrawImage(u32 address, int xStart, int yStart, int xSize, int ySize, const u16 *buffer);

void SRAM_CopyFont(long address, u16 x1, u16 y1, u16 x2, char *pStr, u16 color);
void SRAM_CopyFontBg(long address, u16 x1, u16 y1, u16 x2, char *pStr, u16 FontColor, u16 BgColor);
void SRAM_CopyFontUni(long address, u16 xStart, u16 yStart, u8 *pStr, u16 color);


#endif
