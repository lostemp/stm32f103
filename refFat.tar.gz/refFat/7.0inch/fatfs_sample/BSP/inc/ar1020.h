/*****************************************************************************
* Copyright(C) 2013 Dong-A University MICCA
* All right reserved.
*
* File name	    : ar1020.h
* Last version	: V1.00
* Description	: This file is header file for ar1020 driver.
*
* History
* Date		    Version	    Author			Description
* 2013/05/01	1.00		oh woomin	    Created
*****************************************************************************/
#ifndef __AR1020_H
#define __AR1020_H

/* Defines -------------------------------------------------------------------*/
#define AR1020_ADDR    0x9A

#define AR1020_IRQ_PERIPH       RCC_AHB1Periph_GPIOA
#define AR1020_IRQ_BIT          GPIO_Pin_5
#define AR1020_IRQ_PORT         GPIOA

/* Function prototypes -------------------------------------------------------*/
void AR1020_Init(void);
ErrorStatus AR1020_Write(u8 SlaveAddr, int NumByteToWrite, u8 *buffer);
ErrorStatus AR1020_Read(u8 SlaveAddr, int NumByteToRead, u8 *buffer);

#endif
