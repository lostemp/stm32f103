/**
  ******************************************************************************
  * @file    DCMI/Camera/dcmi_OV7670.c
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    30-September-2011
  * @brief   This file includes the driver for OV7670 Camera module mounted on 
  *          STM324xG-EVAL board RevA and RevB.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>

#include "stm32f4xx.h"
#include "dcmi_ov7670.h"
#include "delay.h"
#include "stm32_uart.h"
#include "sccb.h"

#define DCMI_DR_ADDRESS         0x50050028
#define FSMC_LCD_ADDRESS        0x68000002
#define Bank1_SRAM2_ADDR        0x64000000

#define SRAM_CAMERA_ADDR        0
#define DCMI_IMAGE_SRAM_ADDRESS (Bank1_SRAM2_ADDR+SRAM_CAMERA_ADDR)

/** @addtogroup STM32F4xx_StdPeriph_Examples
  * @{
  */

/** @addtogroup DCMI_Camera
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define  TIMEOUT    2

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* QVGA 640x480 */
static const unsigned char OV7670_VGA[167][2]=
{        
	{0x3a, 0x04},
	{0x40, 0xd0},
	{0x12, 0x04},
	{0x32, 0x80},
	{0x17, 0x16},
	{0x18, 0x04},
	{0x19, 0x02},
	{0x1a, 0x7a},
	{0x03, 0x0a},
	{0x0c, 0x00},
	{0x3e, 0x00},
	{0x70, 0x00},
	{0x71, 0x01},
	{0x72, 0x11},
	{0x73, 0x00},
	{0xa2, 0x02},
	{0x11, 0x02},       // 0x01(15f), 0x03(30f)
	{0x7a, 0x20},
	{0x7b, 0x1c},
	{0x7c, 0x28},
	{0x7d, 0x3c},
	{0x7e, 0x55},
	{0x7f, 0x68},
	{0x80, 0x76},
	{0x81, 0x80},
	{0x82, 0x88},
	{0x83, 0x8f},
	{0x84, 0x96},
	{0x85, 0xa3},
	{0x86, 0xaf},
	{0x87, 0xc4},
	{0x88, 0xd7},
	{0x89, 0xe8},
	{0x13, 0xe0},
	{0x00, 0x00},
	{0x10, 0x00},
	{0x0d, 0x00},
	{0x14, 0x28},
	{0xa5, 0x05},
	{0xab, 0x07},
	{0x24, 0x75},
	{0x25, 0x63},
	{0x26, 0xA5},
	{0x9f, 0x78},
	{0xa0, 0x68},
	{0xa1, 0x03},
	{0xa6, 0xdf},
	{0xa7, 0xdf},
	{0xa8, 0xf0},
	{0xa9, 0x90},
	{0xaa, 0x94},
	{0x13, 0xe5},
	{0x0e, 0x61},
	{0x0f, 0x4b},
	{0x16, 0x02},
	{0x1e, 0x07},       // 0x37
	{0x21, 0x02},
	{0x22, 0x91},
	{0x29, 0x07},
	{0x33, 0x0b},
	{0x35, 0x0b},
	{0x37, 0x1d},
	{0x38, 0x71},
	{0x39, 0x2a},
	{0x3c, 0x78},
	{0x4d, 0x40},
	{0x4e, 0x20},
	{0x69, 0x55},
	{0x6b, 0x40},
	{0x74, 0x19},
	{0x8d, 0x4f},
	{0x8e, 0x00},
	{0x8f, 0x00},
	{0x90, 0x00},
	{0x91, 0x00},
	{0x92, 0x00},
	{0x96, 0x00},
	{0x9a, 0x80},
	{0xb0, 0x84},
	{0xb1, 0x0c},
	{0xb2, 0x0e},
	{0xb3, 0x82},
	{0xb8, 0x0a},
	{0x43, 0x14},
	{0x44, 0xf0},
	{0x45, 0x34},
	{0x46, 0x58},
	{0x47, 0x28},
	{0x48, 0x3a},
	{0x59, 0x88},
	{0x5a, 0x88},
	{0x5b, 0x44},
	{0x5c, 0x67},
	{0x5d, 0x49},
	{0x5e, 0x0e},
	{0x64, 0x04},
	{0x65, 0x20},
	{0x66, 0x05},
	{0x94, 0x04},
	{0x95, 0x08},
	{0x6c, 0x0a},
	{0x6d, 0x55},
	{0x6e, 0x11},
	{0x6f, 0x9f},
	{0x6a, 0x40},
	{0x01, 0x40},
	{0x02, 0x40},
	{0x13, 0xe7},
	{0x15, 0x08},
	{0x4f, 0x80},
	{0x50, 0x80},
	{0x51, 0x00},
	{0x52, 0x22},
	{0x53, 0x5e},
	{0x54, 0x80},
    {0x55, 0x30},
    {0x56, 0x4a},
    {0x58, 0x1e},	
	{0x41, 0x08},
	{0x3f, 0x05},
	{0x75, 0x05},
	{0x76, 0xe1},
	{0x4c, 0x0F},
	{0x77, 0x0a},
	{0x3d, 0xc2},
	{0x4b, 0x09},
	{0xc9, 0x60},
	{0x41, 0x38},
	{0x56, 0x40},
	{0x34, 0x11},
	{0x3b, 0x02},
	{0xa4, 0x89},
	{0x96, 0x00},
	{0x97, 0x30},
	{0x98, 0x20},
	{0x99, 0x30},
	{0x9a, 0x84},
	{0x9b, 0x29},
	{0x9c, 0x03},
	{0x9d, 0x4c},
	{0x9e, 0x3f},
	{0x78, 0x04},	
	{0x79, 0x01},
	{0xc8, 0xf0},
	{0x79, 0x0f},
	{0xc8, 0x00},
	{0x79, 0x10},
	{0xc8, 0x7e},
	{0x79, 0x0a},
	{0xc8, 0x80},
	{0x79, 0x0b},
	{0xc8, 0x01},
	{0x79, 0x0c},
	{0xc8, 0x0f},
	{0x79, 0x0d},
	{0xc8, 0x20},
	{0x79, 0x09},
	{0xc8, 0x80},
	{0x79, 0x02},
	{0xc8, 0xc0},
	{0x79, 0x03},
	{0xc8, 0x40},
	{0x79, 0x05},
	{0xc8, 0x30},
	{0x79, 0x26},
	{0x09, 0x02},
	{0x3b, 0x42},   
};     

/* QVGA 320x240 */
static const unsigned char OV7670_QVGA[167][2]=
{        
	{0x3a, 0x04},
	{0x40, 0xd0},
	{0x12, 0x14},
	{0x32, 0x80},
	{0x17, 0x16},
	{0x18, 0x04},
	{0x19, 0x02},
	{0x1a, 0x7a},
	{0x03, 0x0a},
	{0x0c, 0x00},
	{0x3e, 0x00},
	{0x70, 0x00},
	{0x71, 0x01},
	{0x72, 0x11},
	{0x73, 0x00},
	{0xa2, 0x02},
	{0x11, 0x01},
	{0x7a, 0x20},
	{0x7b, 0x1c},
	{0x7c, 0x28},
	{0x7d, 0x3c},
	{0x7e, 0x55},
	{0x7f, 0x68},
	{0x80, 0x76},
	{0x81, 0x80},
	{0x82, 0x88},
	{0x83, 0x8f},
	{0x84, 0x96},
	{0x85, 0xa3},
	{0x86, 0xaf},
	{0x87, 0xc4},
	{0x88, 0xd7},
	{0x89, 0xe8},
	{0x13, 0xe0},
	{0x00, 0x00},
	{0x10, 0x00},
	{0x0d, 0x00},
	{0x14, 0x28},
	{0xa5, 0x05},
	{0xab, 0x07},
	{0x24, 0x75},
	{0x25, 0x63},
	{0x26, 0xA5},
	{0x9f, 0x78},
	{0xa0, 0x68},
	{0xa1, 0x03},
	{0xa6, 0xdf},
	{0xa7, 0xdf},
	{0xa8, 0xf0},
	{0xa9, 0x90},
	{0xaa, 0x94},
	{0x13, 0xe5},
	{0x0e, 0x61},
	{0x0f, 0x4b},
	{0x16, 0x02},
	{0x1e, 0x37},   // 0x07
	{0x21, 0x02},
	{0x22, 0x91},
	{0x29, 0x07},
	{0x33, 0x0b},
	{0x35, 0x0b},
	{0x37, 0x1d},
	{0x38, 0x71},
	{0x39, 0x2a},
	{0x3c, 0x78},
	{0x4d, 0x40},
	{0x4e, 0x20},
	{0x69, 0x55},
	{0x6b, 0x40},   // 0x40(Input clock x6)
	{0x74, 0x19},
	{0x8d, 0x4f},
	{0x8e, 0x00},
	{0x8f, 0x00},
	{0x90, 0x00},
	{0x91, 0x00},
	{0x92, 0x00},
	{0x96, 0x00},
	{0x9a, 0x80},
	{0xb0, 0x84},
	{0xb1, 0x0c},
	{0xb2, 0x0e},
	{0xb3, 0x82},
	{0xb8, 0x0a},
	{0x43, 0x14},
	{0x44, 0xf0},
	{0x45, 0x34},
	{0x46, 0x58},
	{0x47, 0x28},
	{0x48, 0x3a},
	{0x59, 0x88},
	{0x5a, 0x88},
	{0x5b, 0x44},
	{0x5c, 0x67},
	{0x5d, 0x49},
	{0x5e, 0x0e},
	{0x64, 0x04},
	{0x65, 0x20},
	{0x66, 0x05},
	{0x94, 0x04},
	{0x95, 0x08},
	{0x6c, 0x0a},
	{0x6d, 0x55},
	{0x6e, 0x11},
	{0x6f, 0x9f},
	{0x6a, 0x40},
	{0x01, 0x40},
	{0x02, 0x40},
	{0x13, 0xe7},
	{0x15, 0x08},
	{0x4f, 0x80},
	{0x50, 0x80},
	{0x51, 0x00},
	{0x52, 0x22},
	{0x53, 0x5e},
	{0x54, 0x80},
    {0x55, 0x30},
    {0x56, 0x4a},
    {0x58, 0x1e},	
	{0x41, 0x08},
	{0x3f, 0x05},
	{0x75, 0x05},
	{0x76, 0xe1},
	{0x4c, 0x0F},
	{0x77, 0x0a},
	{0x3d, 0xc2},
	{0x4b, 0x09},
	{0xc9, 0x60},
	{0x41, 0x38},
	{0x56, 0x40},
	{0x34, 0x11},
	{0x3b, 0x02},
	{0xa4, 0x89},
	{0x96, 0x00},
	{0x97, 0x30},
	{0x98, 0x20},
	{0x99, 0x30},
	{0x9a, 0x84},
	{0x9b, 0x29},
	{0x9c, 0x03},
	{0x9d, 0x4c},
	{0x9e, 0x3f},
	{0x78, 0x04},	
	{0x79, 0x01},
	{0xc8, 0xf0},
	{0x79, 0x0f},
	{0xc8, 0x00},
	{0x79, 0x10},
	{0xc8, 0x7e},
	{0x79, 0x0a},
	{0xc8, 0x80},
	{0x79, 0x0b},
	{0xc8, 0x01},
	{0x79, 0x0c},
	{0xc8, 0x0f},
	{0x79, 0x0d},
	{0xc8, 0x20},
	{0x79, 0x09},
	{0xc8, 0x80},
	{0x79, 0x02},
	{0xc8, 0xc0},
	{0x79, 0x03},
	{0xc8, 0x40},
	{0x79, 0x05},
	{0xc8, 0x30},
	{0x79, 0x26},
	{0x09, 0x02},
	{0x3b, 0x42},   
};     

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Initializes the hardware resources (I2C and GPIO) used to configure 
  *         the OV7670 camera.
  * @param  None
  * @retval None
  */
void OV7670_HW_Init(void) 
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    /*** Configures the DCMI GPIOs to interface with the OV7670 camera module ***/
    /* Enable DCMI GPIOs clocks */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOH | 
                           RCC_AHB1Periph_GPIOI, ENABLE); 
    
    /* Enable DCMI clock */
    RCC_AHB2PeriphClockCmd(RCC_AHB2Periph_DCMI, ENABLE);
    
    /* Connect DCMI pins to AF13 ************************************************/
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_DCMI);
    
    GPIO_PinAFConfig(GPIOH, GPIO_PinSource8, GPIO_AF_DCMI);
    GPIO_PinAFConfig(GPIOH, GPIO_PinSource9, GPIO_AF_DCMI);
    GPIO_PinAFConfig(GPIOH, GPIO_PinSource10, GPIO_AF_DCMI);
    GPIO_PinAFConfig(GPIOH, GPIO_PinSource11, GPIO_AF_DCMI);
    GPIO_PinAFConfig(GPIOH, GPIO_PinSource12, GPIO_AF_DCMI);
    GPIO_PinAFConfig(GPIOH, GPIO_PinSource14, GPIO_AF_DCMI);
    
    GPIO_PinAFConfig(GPIOI, GPIO_PinSource5, GPIO_AF_DCMI);
    GPIO_PinAFConfig(GPIOI, GPIO_PinSource6, GPIO_AF_DCMI);
    GPIO_PinAFConfig(GPIOI, GPIO_PinSource7, GPIO_AF_DCMI);
    GPIO_PinAFConfig(GPIOI, GPIO_PinSource4, GPIO_AF_DCMI);
    
    /* DCMI GPIO configuration **************************************************/
    /* D0..D4(PH9/10/11/12/14), HSYNC(PH8) */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | 
        GPIO_Pin_12 | GPIO_Pin_14| GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;  
    GPIO_Init(GPIOH, &GPIO_InitStructure);
    
    /* D5..D7(PI4/6/7), VSYNC(PI5) */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_5;
    GPIO_Init(GPIOI, &GPIO_InitStructure);
    
    /* PCLK(PA6) */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure); 
}

void OV7670_I2C_Config(void)
{
    SCCB_PortInit();     
}
/**
  * @brief  Resets the OV7670 camera.
  * @param  None
  * @retval None
  */
void OV7670_Reset(void)
{
    OV7670_WriteReg(OV7670_COM7, 0x80);
}

/**
  * @brief  Reads the OV7670 Manufacturer identifier.
  * @param  OV7670ID: pointer to the OV7670 Manufacturer identifier.
  * @retval None
  */
void OV7670_ReadID(OV7670_IDTypeDef* OV7670ID)
{    
    OV7670ID->Manufacturer_ID1 = OV7670_ReadReg(OV7670_MIDH);
    OV7670ID->Manufacturer_ID2 = OV7670_ReadReg(OV7670_MIDL);
    OV7670ID->Version = OV7670_ReadReg(OV7670_VER);
    OV7670ID->PID = OV7670_ReadReg(OV7670_PID);
}

/**
  * @brief  Configures the DCMI/DMA to capture image from the OV7670 camera.
  * @param  ImageFormat: Image format BMP or JPEG
  * @param  BMPImageSize: BMP Image size  
  * @retval None
  */
void OV7670_Init(void)
{
    DCMI_InitTypeDef DCMI_InitStructure;
    DMA_InitTypeDef  DMA_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;    
    
    /* Enable the DMA Stream IRQ Channel */
    NVIC_InitStructure.NVIC_IRQChannel = DMA2_Stream1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
        
    /*** Configures the DCMI to interface with the OV7670 camera module ***/
    /* Enable DCMI clock */
    RCC_AHB2PeriphClockCmd(RCC_AHB2Periph_DCMI, ENABLE);
    
    /* DCMI configuration */ 
    DCMI_InitStructure.DCMI_CaptureMode = DCMI_CaptureMode_Continuous;
    DCMI_InitStructure.DCMI_SynchroMode = DCMI_SynchroMode_Hardware;
    DCMI_InitStructure.DCMI_PCKPolarity = DCMI_PCKPolarity_Falling;
    DCMI_InitStructure.DCMI_VSPolarity = DCMI_VSPolarity_High;
    DCMI_InitStructure.DCMI_HSPolarity = DCMI_HSPolarity_High;
    DCMI_InitStructure.DCMI_CaptureRate = DCMI_CaptureRate_All_Frame;
    DCMI_InitStructure.DCMI_ExtendedDataMode = DCMI_ExtendedDataMode_8b;
    
    /* DCMI configuration */ 
    DCMI_Init(&DCMI_InitStructure);    
    
    /* Configures the DMA2 to transfer Data from DCMI */
    /* Enable DMA2 clock */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
    
    /* DMA2 Stream1 Configuration */
    DMA_DeInit(DMA2_Stream1);
        
    DMA_InitStructure.DMA_Channel = DMA_Channel_1;  
    DMA_InitStructure.DMA_PeripheralBaseAddr = DCMI_DR_ADDRESS;	
    DMA_InitStructure.DMA_Memory0BaseAddr = DCMI_IMAGE_SRAM_ADDRESS;//FSMC_LCD_ADDRESS;//
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
    DMA_InitStructure.DMA_BufferSize = 38400;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//DMA_MemoryInc_Disable;//
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular; //DMA_Mode_Normal; 
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;//DMA_FIFOMode_Disable;//
    DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
    DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
    DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
       
    /* DMA2 IRQ channel Configuration */
    DMA_Init(DMA2_Stream1, &DMA_InitStructure);         
                      
    DMA_DoubleBufferModeConfig(DMA2_Stream1, DCMI_IMAGE_SRAM_ADDRESS + (38400)*4, DMA_Memory_0);    
    DMA_DoubleBufferModeCmd(DMA2_Stream1, ENABLE);
    
    DMA_ITConfig(DMA2_Stream1, DMA_IT_TC, ENABLE );   
}

/**
  * @brief  SConfigures the OV7670 camera in QVGA mode.
  * @param  None
  * @retval None
  */
void OV7670_QVGAConfig(void)
{
    uint32_t i;
    
    /* Initialize OV7670 */
    for(i=0; i<(sizeof(OV7670_QVGA)/2); i++)
    {
        OV7670_WriteReg(OV7670_QVGA[i][0], OV7670_QVGA[i][1]);
    }
}


/**
  * @brief  SConfigures the OV7670 camera in VGA mode.
  * @param  None
  * @retval None
  */
void OV7670_VGAConfig(void)
{
    uint32_t i;
    
    /* Initialize OV7670 */
    for(i=0; i<(sizeof(OV7670_VGA)/2); i++)
    {
        OV7670_WriteReg(OV7670_VGA[i][0], OV7670_VGA[i][1]);
    }
}

/**
  * @brief  Configures the OV7670 camera brightness.
  * @param  Brightness: Brightness value, where Brightness can be: 
  *         positively (0x01 ~ 0x7F) and negatively (0x80 ~ 0xFF)
  * @retval None
  */
void OV7670_BrightnessConfig(uint8_t Brightness)
{
    OV7670_WriteReg(OV7670_BRTN, Brightness);
}

/*****************************************************************************
* Descriptions  : OV7670 write register
* Parameters    : id, data
* Return Value  : error
*****************************************************************************/
uint8_t OV7670_WriteReg(uint16_t id, uint8_t data)
{		
    SCCB_Start();
	if(SCCB_WriteByte(0x42) == 0)
	{
		SCCB_Stop();       
		return 0xFF;
	}
	delay_us(100);
  	if(SCCB_WriteByte(id) == 0)
	{
		SCCB_Stop();               
		return 0xFF;
	}
	delay_us(100);
  	if(SCCB_WriteByte(data) == 0)
	{
		SCCB_Stop();              
		return 0xFF;
	}
  	SCCB_Stop();	
  	return 0;
}

/*****************************************************************************
* Descriptions  : OV7670 read register
* Parameters    : id, data
* Return Value  : error
*****************************************************************************/
uint8_t OV7670_ReadReg(uint16_t id)
{
    uint8_t data = 0;
    
	SCCB_Start();
	if(SCCB_WriteByte(0x42) == 0)
	{
		SCCB_Stop();
		return 0xFF;
	}
	delay_us(100);
  	if(SCCB_WriteByte(id) == 0)
	{
		SCCB_Stop();
		return 0xFF;
	}
	SCCB_Stop();	
	delay_us(100);
	
	SCCB_Start();
	if(SCCB_WriteByte(0x43) == 0)
	{
		SCCB_Stop();
		return 0xFF;
	}
	delay_us(100);
  	data=SCCB_ReadByte();
  	SCCB_NoAck();
  	SCCB_Stop();
  	return data;
}

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
