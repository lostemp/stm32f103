/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : camera_api.c
* Last version	: V1.00
* Description	: This file is source file for camera interface.
*
* History
* Date		    Version	    Author			Description
* 02/02/2012	1.00		oh woomin	    Created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "camera_api.h"
#include "dcmi_ov7670.h"
#include "delay.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

void CameraConfig(void)
{
    OV7670_I2C_Config();
    OV7670_Reset();
    delay_ms(10);
    
    OV7670_ReadReg(OV7670_PID);
            
    // OV7670 �ʱ�ȭ
    OV7670_HW_Init();
    OV7670_Init();
    OV7670_VGAConfig();
    
    /* Enable DMA2 stream 1 and DCMI interface then start image capture */
    DCMI_Cmd(ENABLE);
    DMA_Cmd(DMA2_Stream1, ENABLE);
    DCMI_CaptureCmd(ENABLE);    
}
