/**
  ******************************************************************************
  * @file    DCMI/OV7670_Camera/dcmi_OV7670.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    30-September-2011
  * @brief   Header for dcmi_OV7670.c module
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DCMI_OV7670_H
#define __DCMI_OV7670_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

/* Exported types ------------------------------------------------------------*/
typedef struct
{
  uint8_t Manufacturer_ID1;
  uint8_t Manufacturer_ID2;
  uint8_t Version;
  uint8_t PID;
}OV7670_IDTypeDef;

/* Exported constants --------------------------------------------------------*/

/* Use this define to set the maximum delay timeout for the I2C DCMI_OV7670_SingleRandomWrite()
   and DCMI_OV7670_SingleRandomRead() operations. Exeeding this timeout delay,
   the read/write functions will be aborted and return error code (0xFF).
   The period of the delay will depend on the system operating frequency. The following
   value has been set for system running at 168 MHz. */
#define DCMI_TIMEOUT_MAX  10000

#define OV7670_DEVICE_WRITE_ADDRESS    0x42
#define OV7670_DEVICE_READ_ADDRESS     0x43

/* OV7670 Registers definition */
#define OV7670_GAIN       0x00
#define OV7670_BLUE       0x01
#define OV7670_RED        0x02
#define OV7670_VREF       0x03
#define OV7670_COM1       0x04
#define OV7670_BAVE       0x05
#define OV7670_GbAVE      0x06
#define OV7670_AECHH      0x07
#define OV7670_RAVE       0x08
#define OV7670_COM2       0x09
#define OV7670_PID        0x0A 
#define OV7670_VER        0x0B
#define OV7670_COM3       0x0C
#define OV7670_COM4       0x0D
#define OV7670_COM5       0x0E
#define OV7670_COM6       0x0F
#define OV7670_AEC        0x10
#define OV7670_CLKRC      0x11
#define OV7670_COM7       0x12
#define OV7670_COM8       0x13
#define OV7670_COM9       0x14
#define OV7670_COM10      0x15
#define OV7670_REG16      0x16
#define OV7670_HSTART     0x17
#define OV7670_HSTOP      0x18
#define OV7670_VSTART     0x19
#define OV7670_VSTOP      0x1A
#define OV7670_PSHFT      0x1B
#define OV7670_MIDH       0x1C
#define OV7670_MIDL       0x1D
#define OV7670_BRTN       0x55

/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

void OV7670_HW_Init(void);
void OV7670_Reset(void);
void OV7670_ReadID(OV7670_IDTypeDef* OV7670ID);
void OV7670_Init(void);
void OV7670_QVGAConfig(void);
void OV7670_VGAConfig(void);
void OV7670_BrightnessConfig(uint8_t Brightness);
uint8_t OV7670_WriteReg(uint16_t Addr, uint8_t Data);
uint8_t OV7670_ReadReg(uint16_t Addr);
void OV7670_I2C_Config(void);

#endif /* __DCMI_OV7670_H */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/

