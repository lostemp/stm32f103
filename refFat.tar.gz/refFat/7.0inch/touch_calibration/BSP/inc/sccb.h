/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : sccb.h
* Last version	: V1.00
* Description	: This file is header file for sccb interface
*
* History
* Date		    Version	    Author			Description
* 07/16/2011	1.00		oh woomin	    Created
*****************************************************************************/

#ifndef __SCCB_H
#define __SCCB_H

/* Exported constants --------------------------------------------------------*/
#define SCCB_SIC_PERIPH         RCC_AHB1Periph_GPIOB
#define SCCB_SIC_BIT            GPIO_Pin_8
#define SCCB_SIC_PORT           GPIOB

#define SCCB_SID_PERIPH         RCC_AHB1Periph_GPIOB
#define SCCB_SID_BIT            GPIO_Pin_9
#define SCCB_SID_PORT           GPIOB

#define SCCB_SIC_H()            SCCB_SIC_PORT->BSRRL = SCCB_SIC_BIT
#define SCCB_SIC_L()            SCCB_SIC_PORT->BSRRH =  SCCB_SIC_BIT
#define SCCB_SID_H()            SCCB_SID_PORT->BSRRL = SCCB_SID_BIT
#define SCCB_SID_L()            SCCB_SID_PORT->BSRRH =  SCCB_SID_BIT

#define SCCB_SID_STATE()        (SCCB_SID_PORT->IDR & SCCB_SID_BIT)

/* Exported functions ------------------------------------------------------- */
void SCCB_PortInit(void);
void SCCB_Start(void);
void SCCB_Stop(void);
void SCCB_NoAck(void);
unsigned char SCCB_WriteByte(unsigned char m_data);
unsigned char SCCB_ReadByte(void);

#endif
