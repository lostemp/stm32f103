/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : camera_api.h
* Last version	: V1.00
* Description	: This file is header file for camera interface.
*
* History
* Date		    Version	    Author			Description
* 02/02/2012	1.00		oh woomin	    Created
*****************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CAMERA_API_H
#define __CAMERA_API_H

/* Includes ------------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void CameraConfig(void);

#endif /* __CAMERA_API_H */

