
void TouchConfig(void);
ErrorStatus CalibratePoint(void);
ErrorStatus GetDisplayPoint(u16 *x, u16 *y);