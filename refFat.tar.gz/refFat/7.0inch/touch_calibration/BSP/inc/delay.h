/************************** (C) COPYRIGHT 2008 MICCA **************************
* File Name         : delay.h
* Author            : MICCA 14th oh woo min
* Version           : V1.00
* Date              : 07/07/2008
* Description       : This moudule is microsecond(us), millisecond(ms) delay header file.
*
* Revision History
* Date          Version       Name          Description
* 07/07/2008    1.00          oh woo min    created
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

/* Function prototypes -------------------------------------------------------*/
void delay_us(vu32 nCount);
void delay_ms(vu32 nCount);
