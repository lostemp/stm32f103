
#ifndef __TYPEDEF_H
#define __TYPEDEF_H

typedef struct
{
    int x, y;   
}POINT;

typedef enum {false, true} bool;

#endif