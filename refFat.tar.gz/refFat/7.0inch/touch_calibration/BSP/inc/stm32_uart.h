/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : stm32_uart.h
* Last version	: V2.00
* Description	: This file is header file for uart function.
*
* History
* Date		    Version	    Author			Description
* 03/06/2011	2.00		oh woomin	    V2.00 created
*****************************************************************************/

#ifndef STM32_UART_H
#define STM32_UART_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "queue.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
#define UART1           1
#define UART3           3
#define BUFFER_SIZE     256

/* Exported variables ---------------------------------------------------------*/
extern QueueType Uart1RxQueue, Uart3RxQueue;
extern QueueType Uart1TxQueue, Uart3TxQueue;

/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void UART_Init(u8 uart,u32 baud);

ErrorStatus UART1_PutChar(const char ascii);
ErrorStatus UART1_GetChar(char *data);
void UART1_PutStr(char *string);
void UART1_printf(const char *fmt,...);

ErrorStatus UART3_PutChar(const char ascii);
ErrorStatus UART3_GetChar(char *data);
void UART3_PutStr(char *string);
void UART3_printf(const char *fmt,...);


#endif
