/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : stm32_systick.h
* Last version	: V1.00
* Description	: This file is header file for systick timer.
*
* History
* Date		    Version	    Author			Description
* 03/06/2011	1.00		oh woomin	    create
*****************************************************************************/

void SystickInit(uint32_t time);
void TimeDelay(uint32_t time);
void DecrementTimingDelay(void);
