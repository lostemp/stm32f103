/*****************************************************************************
* Copyright(C) 2013 Dong-A University MICCA
* All right reserved.
*
* File name	    : main.c
* Platform 
* - Target Board: STM3240IG Module + 7.0" SSD1963 Module
* - Complier    : IAR EWARM V6.30
* - Library     : Stdperiph driver V1.10
*
* Last version	: V1.00
* Description	: This file is main program for touch controller(AR1020) Calibration.
*
* History
* Date		    Version	    Author			Description
* 05/01/2013    1.00        oh woomin       Created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include "stm32f4xx.h"
#include "stm32f4xx_it.h"
#include "platform_config.h"
#include "typedef.h"
#include "delay.h"
#include "stm32_uart.h"
#include "tftlcd.h"
#include "rgb_color_table.h"
#include "stm324xg_fsmc_sram.h"
#include "stm32_systick.h"
#include "touch_api.h"

/* Privated macro ----------------------------------------------------------*/
/* Privated defines --------------------------------------------------------*/
// SRAM address area
#define Bank1_SRAM2_ADDR        0x64000000
#define SRAM_CAMERA_ADDR        0
#define DCMI_IMAGE_SRAM_ADDRESS (Bank1_SRAM2_ADDR+SRAM_CAMERA_ADDR)

/* Privated variables ------------------------------------------------------*/
POINT DispPoint;
u16 FontColor = RGB_BLACK, BgColor = RGB_WHITE;

/* Privated typedef --------------------------------------------------------*/
typedef enum {CAMERA_SCREEN, PHOTO_SCREEN, FILE_SCREEN} ScreenType;

/* Privated function prototypes --------------------------------------------*/

/*****************************************************************************
* Descriptions : Configure the user LED
* Parameters : None
* Return Value : None
*****************************************************************************/
void UserLedConfig(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
            
    /* GPIOF Periph clock enable */
    RCC_AHB1PeriphClockCmd(LED_PERIPH, ENABLE);
    
    /* Configure PG6 and PG8 in output pushpull mode */
    GPIO_InitStructure.GPIO_Pin = LED1_BIT | LED2_BIT |LED3_BIT | LED4_BIT;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(LED_PORT, &GPIO_InitStructure);
    
    LED1_OFF(); LED2_OFF(); LED3_OFF(); LED4_OFF();       
}

/*****************************************************************************
* Descriptions : Configure the user switch
* Parameters : None
* Return Value : None
*****************************************************************************/
void UserSwConfig(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
    
	/* Enable the user SW1, SW2 clock */
	RCC_APB1PeriphClockCmd(USER_SW_PERIPH, ENABLE);
    
	/* Configure the user SW1, SW2 pin */
    GPIO_InitStructure.GPIO_Pin = USER_SW1_BIT | USER_SW2_BIT;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
    GPIO_Init(USER_SW_PORT, &GPIO_InitStructure);
}

/*****************************************************************************
* Descriptions : Initializes the system
* Parameters : None
* Return Value : None
*****************************************************************************/
void SystemConfig(void)
{
    UserLedConfig();
    UserSwConfig();
    UART_Init(UART1, 115200);
    UART_Init(UART3, 115200);
    SystickInit(1000);          // Systick timer 1kHz = 1ms  
    SRAM_Init();
    
    TFTLCD_Init();
    TFTLCD_SetBackLight(220);   // Backlight brightness 0(min)~255(max)
    TFTLCD_BL_ON();
    TFTLCD_Landscape();
    
    TouchConfig();
}

/*****************************************************************************
* Descriptions : Main program
* Parameters : None
* Return Value : None
*****************************************************************************/
int main(void)
{       
    u16 x, y;    
    
    SystemConfig();            
    TFTLCD_printf(32, 4, RGB_ORANGE, RGB_WHITE, "Touch Screen Calibration Program");   

    ClearSystickEvent();
    printf("Touch Controller Calibration Program\r\n");

    while(1)
    {
        // Touch screen calibration
        if(USER_SW1_PUSH())
        {
            CalibratePoint();        
            TFTLCD_printf(32, 4, RGB_ORANGE, RGB_WHITE, 
                          "Touch Screen Calibration Program");            
        }        
        
        // Get touch screen point (each 5ms)
        if(Event.Touch)
        {
            Event.Touch = 0;
            if(GetDisplayPoint(&x, &y) == SUCCESS)
            {
                TFTLCD_printf(1, 29, RGB_GRAY, RGB_WHITE, "Point:(%04d,%04d)", x, y);
                TFTLCD_DrawPen(x, y, RGB_BLUE);
            }
        }
        
        // LED1 toggle each 100ms
        if(Event.Led1)
        {
            Event.Led1 = 0;
            LED1_TOGGLE();
        }        
    }
}

