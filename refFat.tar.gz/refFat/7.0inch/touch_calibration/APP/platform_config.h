/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : platform_config.h
* Last version	: 1.00
* Description	: This file contains definitions for STM32E_Module hardware resources
*
* History
* Date		    Version	    Author			Description
* 02/06/2011	1.00		oh woomin	    Created
*****************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __PLATFORM_CONFIG_H
#define __PLATFORM_CONFIG_H

/* Define the STM32F10x hardware depending on the used evaluation board */
#define LED_PERIPH          RCC_AHB1Periph_GPIOF
#define LED_PORT            GPIOF
#define LED1_BIT            GPIO_Pin_9
#define LED2_BIT            GPIO_Pin_8
#define LED3_BIT            GPIO_Pin_7
#define LED4_BIT            GPIO_Pin_6

// Switch
#define USER_SW_PERIPH      RCC_AHB1Periph_GPIOB
#define USER_SW_PORT        GPIOB
#define USER_SW1_BIT	    GPIO_Pin_0
#define USER_SW2_BIT	    GPIO_Pin_1

/* Exported macro ------------------------------------------------------------*/
#define LED1_LOW()          (LED_PORT->BSRRH = LED1_BIT)
#define LED1_HIGH()         (LED_PORT->BSRRL = LED1_BIT)
#define LED1_ON()           (LED_PORT->BSRRH = LED1_BIT)
#define LED1_OFF()          (LED_PORT->BSRRL = LED1_BIT)
#define LED1_TOGGLE()       (LED_PORT->ODR ^= LED1_BIT)
#define LED2_LOW()          (LED_PORT->BSRRH = LED2_BIT)
#define LED2_HIGH()         (LED_PORT->BSRRL = LED2_BIT)
#define LED2_ON()           (LED_PORT->BSRRH = LED2_BIT)
#define LED2_OFF()          (LED_PORT->BSRRL = LED2_BIT)
#define LED2_TOGGLE()       (LED_PORT->ODR ^= LED2_BIT)
#define LED3_LOW()          (LED_PORT->BSRRH = LED3_BIT)
#define LED3_HIGH()         (LED_PORT->BSRRL = LED3_BIT)
#define LED3_ON()           (LED_PORT->BSRRH = LED3_BIT)
#define LED3_OFF()          (LED_PORT->BSRRL = LED3_BIT)
#define LED3_TOGGLE()       (LED_PORT->ODR ^= LED3_BIT)
#define LED4_LOW()          (LED_PORT->BSRRH = LED4_BIT)
#define LED4_HIGH()         (LED_PORT->BSRRL = LED4_BIT)
#define LED4_ON()           (LED_PORT->BSRRH = LED4_BIT)
#define LED4_OFF()          (LED_PORT->BSRRL = LED4_BIT)
#define LED4_TOGGLE()       (LED_PORT->ODR ^= LED4_BIT)

#define USER_SW1_PUSH()     !GPIO_ReadInputDataBit(USER_SW_PORT, USER_SW1_BIT)
#define USER_SW2_PUSH()     !GPIO_ReadInputDataBit(USER_SW_PORT, USER_SW2_BIT)

#endif /* __PLATFORM_CONFIG_H */